"""Summarize reference labels and a provisional ZIP index without accessing image pixels."""

import argparse
import collections
import csv
import hashlib
import io
import json
import struct
import zipfile
from pathlib import Path, PurePosixPath

from scripts.dataset import ROOT, validate_member

LABELS = {"0": "Pitta", "1": "Vata", "2": "Kapha"}
DEFAULT_CSV = ROOT / "reference/Tonge-Image-Classification/20240514-3TTM-class.csv"


def read_labels(path: Path) -> tuple[list[dict[str, str]], dict]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        required = {"Filename", "ID", "Camera", "Class"}
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError("Reference CSV is missing required columns")
        rows = list(reader)
    if not rows:
        raise ValueError("Reference CSV has no rows")
    if any(not row["Filename"] or not row["ID"] or row["Class"] not in LABELS for row in rows):
        raise ValueError("Reference CSV contains missing identifiers or unknown labels")
    classes = collections.Counter(row["Class"] for row in rows)
    candidates = collections.defaultdict(set)
    for row in rows:
        candidates[row["ID"]].add(row["Class"])
    result = {
        "rows": len(rows),
        "csv_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "candidate_ids": len(candidates),
        "conflicting_candidate_ids": sum(len(classes) > 1 for classes in candidates.values()),
        "class_counts": {LABELS[key]: classes[key] for key in LABELS},
        "filename_duplicates": len(rows) - len({row["Filename"].casefold() for row in rows}),
    }
    return rows, result


def read_central_directory(path: Path) -> tuple[list[zipfile.ZipInfo], str]:
    data = path.read_bytes()
    if not data or len(data) > 10 * 1024 * 1024:
        raise ValueError("Invalid or unexpectedly large ZIP central-directory fragment")
    count = 0
    cursor = 0
    while cursor < len(data):
        if len(data) - cursor < 46:
            raise ValueError("Truncated ZIP central-directory header")
        fields = struct.unpack_from("<4s6H3I5H2I", data, cursor)
        if fields[0] != b"PK\x01\x02":
            raise ValueError("Invalid ZIP central-directory signature")
        cursor += 46 + fields[10] + fields[11] + fields[12]
        count += 1
        if cursor > len(data) or count > 65_535:
            raise ValueError("Truncated or unsupported ZIP central directory")
    end = struct.pack("<4s4H2LH", b"PK\x05\x06", 0, 0, count, count, len(data), 0, 0)
    with zipfile.ZipFile(io.BytesIO(data + end)) as archive:
        members = archive.infolist()
    if len(members) != count:
        raise ValueError("ZIP central-directory entry count mismatch")
    for member in members:
        validate_member(member)
    return members, hashlib.sha256(data).hexdigest()


def summarize_index(
    rows: list[dict[str, str]], members: list[zipfile.ZipInfo], digest: str
) -> dict:
    crop_stems = collections.Counter()
    by_folder = collections.Counter()
    for member in members:
        if member.is_dir():
            continue
        path = PurePosixPath(member.filename)
        parts = path.parts
        if len(parts) == 3 and parts[0] == "Crop_images" and path.suffix.lower() == ".jpg":
            crop_stems[path.stem.casefold()] += 1
            by_folder["crop_photographs"] += 1
        elif len(parts) == 4 and parts[0] == "ROI_images" and path.suffix.lower() == ".png":
            if parts[2] == "image":
                by_folder["roi_images"] += 1
            elif parts[2] == "mask":
                by_folder["roi_masks"] += 1
    label_stems = {row["Filename"].casefold() for row in rows}
    crop_names = set(crop_stems)
    return {
        "status": "provisional index only; full archive checksum and image validation pending",
        "central_sha256": digest,
        "archive_entries": len(members),
        "uncompressed_bytes": sum(member.file_size for member in members),
        "crop_photographs": by_folder["crop_photographs"],
        "roi_images": by_folder["roi_images"],
        "roi_masks": by_folder["roi_masks"],
        "unlabeled_crop_stems": len(crop_names - label_stems),
        "missing_labeled_crop_stems": len(label_stems - crop_names),
        "duplicate_crop_stems": sum(count > 1 for count in crop_stems.values()),
    }


def build_report(csv_path: Path, central_path: Path) -> dict:
    rows, label_summary = read_labels(csv_path)
    members, digest = read_central_directory(central_path)
    return {
        "purpose": "preliminary research dataset audit, not a diagnosis",
        "label_summary": label_summary,
        "archive_index": summarize_index(rows, members, digest),
        "subject_id_semantics": "unverified candidate identifier, not confirmed subject identity",
        "images_decoded": False,
        "archive_checksum_verified": False,
        "trained_model": False,
    }


def render_html(report: dict) -> str:
    labels = report["label_summary"]
    index = report["archive_index"]
    counts = labels["class_counts"]
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#f6f8f8"><title>Jeevah — Phase 1 Research Audit</title>
<style>
:root {{ color-scheme: light; font-family: system-ui, sans-serif; color: #102c31; background: #f6f8f8; }}
* {{ box-sizing: border-box; }} body {{ margin: 0; line-height: 1.55; }}
.skip {{ position: absolute; top: -4rem; left: 1rem; background: white; padding: .6rem; z-index: 1; }}
.skip:focus {{ top: .5rem; }} a:focus-visible {{ outline: 3px solid #a65d06; outline-offset: 4px; }}
.top {{ background: #153b40; color: #fff; padding: 1rem max(1.25rem, calc((100% - 1120px)/2)); }}
.top strong {{ letter-spacing: .08em; }} .top span {{ color: #c5d9d8; font-size: .84rem; margin-left: .8rem; }}
main {{ max-width: 1120px; margin: auto; padding: 2.5rem 1.25rem 4rem; }}
.eyebrow {{ text-transform: uppercase; letter-spacing: .11em; font-weight: 700; color: #2a6868; font-size: .78rem; }}
h1 {{ font-size: clamp(2rem, 5vw, 3.2rem); line-height: 1.1; margin: .5rem 0 1rem; text-wrap: balance; }}
h2 {{ font-size: 1.25rem; margin: 0 0 .65rem; }} p {{ max-width: 75ch; }}
.intro {{ color: #425e61; font-size: 1.08rem; }}
.notice {{ margin: 1.7rem 0; background: #fff5e3; border-left: 4px solid #a96108; border-radius: .35rem; padding: 1rem 1.2rem; color: #573a15; }}
.notice p {{ margin: .25rem 0; }} .grid {{ display: grid; gap: 1rem; grid-template-columns: repeat(4, minmax(0,1fr)); }}
.card, .panel {{ background: white; border: 1px solid #dce6e5; border-radius: .8rem; padding: 1.3rem; }}
.card span {{ display: block; color: #425e61; font-size: .9rem; }} .metric {{ font-size: 2rem; font-weight: 750; font-variant-numeric: tabular-nums; line-height: 1.2; margin: .5rem 0; }}
.card small {{ color: #4a6264; }} .panels {{ display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1.5rem; }}
.panel p {{ color: #425e61; }} table {{ width: 100%; border-collapse: collapse; font-variant-numeric: tabular-nums; }}
th, td {{ padding: .65rem 0; border-bottom: 1px solid #e8eeee; text-align: left; }} td:last-child, th:last-child {{ text-align: right; }}
.issue {{ border-top: 1px solid #e8eeee; padding: .8rem 0; display: flex; justify-content: space-between; gap: 1rem; }}
.issue strong {{ color: #89480a; white-space: nowrap; }} .footer {{ color: #526b6c; font-size: .9rem; margin-top: 2rem; }}
@media (max-width: 760px) {{ .grid {{ grid-template-columns: repeat(2, minmax(0,1fr)); }} .panels {{ grid-template-columns: 1fr; }} }}
@media (max-width: 380px) {{ .grid {{ grid-template-columns: 1fr; }} .top span {{ display: block; margin-left: 0; }} }}
</style></head><body><a class="skip" href="#main">Skip to main content</a>
<header class="top"><strong>JEEVAH</strong><span>LOCAL RESEARCH WORKSPACE</span></header>
<main id="main"><span class="eyebrow">Phase 01 / dataset audit</span><h1>Know the data<br>before the model.</h1>
<p class="intro">A historical preliminary review of the reference labels and archive index. Counts on this page are not a current training-readiness assessment.</p>
<div class="notice" role="note"><strong>Research only · Not a disease diagnosis</strong>
<p>The source predicts Traditional Thai Medicine Pitta, Vata and Kapha categories, not diseases. This page contains no prediction and is not the final product interface.</p></div>
<section aria-labelledby="snapshot"><h2 id="snapshot">Label snapshot</h2><div class="grid">
<div class="card"><span>CSV label rows</span><div class="metric">{labels["rows"]:,}</div><small>Reference label file</small></div>
<div class="card"><span>Candidate IDs</span><div class="metric">{labels["candidate_ids"]:,}</div><small>Subject identity not confirmed</small></div>
<div class="card"><span>Crop photographs</span><div class="metric">{index["crop_photographs"]:,}</div><small>Archive index only</small></div>
<div class="card"><span>ROI masks</span><div class="metric">{index["roi_masks"]:,}</div><small>Not classification photographs</small></div>
</div></section><div class="panels"><section class="panel" aria-labelledby="classes"><h2 id="classes">Label distribution</h2>
<p>Counts refer to CSV rows, not independently verified people.</p><table><thead><tr><th scope="col">Category</th><th scope="col">Rows</th></tr></thead><tbody>
<tr><th scope="row">Pitta</th><td>{counts["Pitta"]:,}</td></tr><tr><th scope="row">Vata</th><td>{counts["Vata"]:,}</td></tr>
<tr><th scope="row">Kapha</th><td>{counts["Kapha"]:,}</td></tr></tbody></table></section>
<section class="panel" aria-labelledby="issues"><h2 id="issues">Issues requiring review</h2><p>These initial discrepancies require review; a separate experimental model is not an approved release.</p>
<div class="issue"><span>Candidate IDs with conflicting class labels</span><strong>{labels["conflicting_candidate_ids"]}</strong></div>
<div class="issue"><span>Crop filename stems without CSV labels</span><strong>{index["unlabeled_crop_stems"]}</strong></div>
<div class="issue"><span>CSV filename stems missing from crop index</span><strong>{index["missing_labeled_crop_stems"]}</strong></div>
<div class="issue"><span>Duplicate crop filename stems</span><strong>{index["duplicate_crop_stems"]}</strong></div></section></div>
<p class="footer"><strong>Historical snapshot:</strong> this page uses the CSV and a provisional archive index, not live dataset or model status. See the project validation record for current results. The separate <a href="http://127.0.0.1:5173/">experimental prediction dashboard</a> must be started independently; it is research-only and not a medical diagnosis.</p>
</main></body></html>"""


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, default=DEFAULT_CSV)
    parser.add_argument("--central", type=Path, default=ROOT / ".tools/zenodo-central.bin")
    parser.add_argument("--output", type=Path, default=ROOT / "artifacts/reference-audit")
    args = parser.parse_args()
    report = build_report(args.csv, args.central)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (args.output / "index.html").write_text(render_html(report), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print(f"\nLocal preview: {args.output / 'index.html'}")


if __name__ == "__main__":
    main()
