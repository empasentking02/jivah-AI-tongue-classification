$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
Set-Location -LiteralPath $root
$version = '22.23.4'
$runtime = Join-Path $root ".tools\node-v$version-win-x64"
$archive = Join-Path $root ".tools\node-v$version-win-x64.zip"
$expectedHash = 'CBC74B5E0982C9DBB41525FD8FB5DCD32FBEE237863F7829072F4639A1CE5F20'
New-Item -ItemType Directory -Force -Path '.tools' | Out-Null
if (-not (Test-Path -LiteralPath (Join-Path $runtime 'node.exe'))) {
    if (-not (Test-Path -LiteralPath $archive)) {
        Invoke-WebRequest "https://nodejs.org/dist/v$version/node-v$version-win-x64.zip" -OutFile $archive
    }
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne $expectedHash) {
        throw 'Node archive checksum mismatch. Do not use this runtime.'
    }
    Expand-Archive -LiteralPath $archive -DestinationPath '.tools' -Force
}
$actualVersion = & (Join-Path $runtime 'node.exe') --version
if ($actualVersion -ne "v$version") { throw 'Unexpected local Node version' }
& (Join-Path $PSScriptRoot 'npm.ps1') ci
if ($LASTEXITCODE -ne 0) { throw 'npm ci failed' }
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
    py -3.13 -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.13 is required' }
}
$python = Join-Path $root '.venv\Scripts\python.exe'
& $python -m pip install -r requirements.lock.txt
if ($LASTEXITCODE -ne 0) { throw 'Python dependency installation failed' }
& $python -m pip check
if ($LASTEXITCODE -ne 0) { throw 'Python dependency check failed' }
Write-Output 'Dependencies ready. Dataset acquisition is a separate explicit command; see README.md.'
