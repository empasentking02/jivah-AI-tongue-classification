"""Run the research UI and API locally in one terminal."""

import argparse
import os
import subprocess
import threading
from pathlib import Path

import uvicorn

ROOT = Path(__file__).resolve().parents[1]
NODE = ROOT / ".tools/node-v22.23.4-win-x64/node.exe"
VITE = ROOT / "node_modules/vite/bin/vite.js"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experimental", action="store_true")
    args = parser.parse_args()
    if not NODE.is_file() or not VITE.is_file():
        raise SystemExit("Web dependencies are missing. Run .\\scripts\\setup.ps1 first.")

    if args.experimental:
        run = ROOT / "artifacts/retrain-head-20261108"
        required = {
            "JEEVAH_MODEL_PATH": run / "best.keras",
            "JEEVAH_METADATA_PATH": run / "metadata.json",
            "JEEVAH_EVALUATION_PATH": run / "test.json",
        }
        if not all(path.is_file() for path in required.values()):
            raise SystemExit("Experimental model or held-out evaluation is not available yet.")
        os.environ.update({key: str(path) for key, path in required.items()})
        os.environ["JEEVAH_EXPERIMENTAL"] = "1"

    server = uvicorn.Server(
        uvicorn.Config("services.api.main:app", host="127.0.0.1", port=8000, log_level="info")
    )
    web = subprocess.Popen(
        [str(NODE), str(VITE), "apps/web", "--host", "127.0.0.1", "--port", "5173", "--strictPort"],
        cwd=ROOT,
    )

    def watch_web() -> None:
        web.wait()
        server.should_exit = True

    watcher = threading.Thread(target=watch_web, daemon=True)
    watcher.start()
    print("Open http://127.0.0.1:5173/; press Ctrl+C to stop both servers.", flush=True)
    if args.experimental:
        print("Unreviewed experimental research model; NOT a medical diagnosis.", flush=True)
    else:
        print("Without an approved trained model, predictions remain unavailable.", flush=True)
    try:
        server.run()
    finally:
        if web.poll() is None:
            web.terminate()
            try:
                web.wait(timeout=5)
            except subprocess.TimeoutExpired:
                web.kill()
                web.wait()


if __name__ == "__main__":
    main()
