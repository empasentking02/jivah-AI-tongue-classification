$ErrorActionPreference = 'Stop'
$NpmArguments = $args
if ($NpmArguments.Count -gt 1 -and $NpmArguments[0] -eq 'exec' -and
    $NpmArguments -notcontains '--' -and -not $NpmArguments[1].StartsWith('-')) {
    $NpmArguments = @('exec', '--') + $NpmArguments[1..($NpmArguments.Count - 1)]
}
$runtime = Join-Path $PSScriptRoot '..\.tools\node-v22.23.4-win-x64'
$node = Join-Path $runtime 'node.exe'
$cli = Join-Path $runtime 'node_modules\npm\bin\npm-cli.js'
if (-not (Test-Path -LiteralPath $node)) { throw 'Local Node runtime missing. See README.md.' }
$env:PATH = $runtime + ';' + $env:PATH
$env:DISABLE_TELEMETRY = '1'
& $node $cli @NpmArguments
exit $LASTEXITCODE
