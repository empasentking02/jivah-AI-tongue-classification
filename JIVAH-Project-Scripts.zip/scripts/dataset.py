"""Acquire the publisher archive; never train from an unverified partial download."""

import argparse
import contextlib
import hashlib
import json
import os
import shutil
import stat
import subprocess
import time
import zipfile
from pathlib import Path, PurePosixPath, PureWindowsPath

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / "dataset/archives/tongue-dataset.zip"
PARTIAL = ARCHIVE.with_suffix(".zip.part")
URL = "https://zenodo.org/api/records/12525502/files/tongue-dataset.zip/content"
EXPECTED_BYTES = 3_694_327_548
EXPECTED_MD5 = "a6fa5026c9ac06e833ce74e6358dd20a"
MAX_EXTRACTED = 50 * 1024**3
MAX_STALLED_ATTEMPTS = 8


@contextlib.contextmanager
def acquisition_lock(directory: Path):
    directory.mkdir(parents=True, exist_ok=True)
    lock_file = (directory / ".download.lock").open("a+b")
    try:
        if os.name == "nt":
            import msvcrt

            lock_file.seek(0)
            try:
                msvcrt.locking(lock_file.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as error:
                raise RuntimeError("Another dataset acquisition is already running") from error
        else:
            import fcntl

            try:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as error:
                raise RuntimeError("Another dataset acquisition is already running") from error
        yield
    finally:
        lock_file.close()


def download_archive(curl: str) -> None:
    stalled_attempts = 0
    while True:
        previous_size = PARTIAL.stat().st_size if PARTIAL.exists() else 0
        if previous_size > EXPECTED_BYTES:
            raise ValueError("Partial download exceeds the publisher's archive size")
        if previous_size == EXPECTED_BYTES:
            return
        remaining = EXPECTED_BYTES - previous_size
        if shutil.disk_usage(PARTIAL.parent).free < remaining + 2 * 1024**3:
            raise ValueError("Insufficient disk space for the download plus 2 GiB headroom")
        result = subprocess.run(
            [
                curl,
                "--location",
                "--fail",
                "--silent",
                "--show-error",
                "--connect-timeout",
                "30",
                "--speed-limit",
                "1024",
                "--speed-time",
                "120",
                "--continue-at",
                "-",
                "--output",
                str(PARTIAL),
                URL,
            ],
            check=False,
        )
        current_size = PARTIAL.stat().st_size if PARTIAL.exists() else 0
        if current_size > EXPECTED_BYTES or current_size < previous_size:
            raise ValueError(
                "Downloaded byte count is invalid; preserve the partial file for review"
            )
        if result.returncode == 0 and current_size == EXPECTED_BYTES:
            return
        if current_size > previous_size:
            stalled_attempts = 0
        else:
            stalled_attempts += 1
        print(
            f"Transfer interrupted (curl {result.returncode}); "
            f"retained {current_size}/{EXPECTED_BYTES} bytes; "
            f"consecutive attempts without progress: {stalled_attempts}/{MAX_STALLED_ATTEMPTS}",
            flush=True,
        )
        if stalled_attempts >= MAX_STALLED_ATTEMPTS:
            raise RuntimeError("Dataset transfer stalled; inspect logs and retry later")
        time.sleep(min(5 * (stalled_attempts + 1), 60))


def validate_member(member: zipfile.ZipInfo) -> PurePosixPath:
    name = member.orig_filename
    path = PurePosixPath(name)
    windows = PureWindowsPath(name)
    if (
        not name
        or not path.parts
        or chr(0) in name
        or chr(92) in name
        or path.is_absolute()
        or windows.drive
        or ".." in path.parts
    ):
        raise ValueError(f"Unsafe archive path: {name!r}")
    if any(":" in part or part.endswith((".", " ")) for part in path.parts):
        raise ValueError(f"Ambiguous Windows path: {name!r}")
    if hasattr(os.path, "isreserved") and any(os.path.isreserved(part) for part in path.parts):
        raise ValueError(f"Reserved Windows path: {name!r}")
    if stat.S_ISLNK(member.external_attr >> 16):
        raise ValueError(f"Archive symlink rejected: {name!r}")
    if member.file_size > 2 * 1024**3:
        raise ValueError(f"Archive member exceeds 2 GiB: {name!r}")
    return path


def inspect_archive(archive: Path) -> list[zipfile.ZipInfo]:
    with zipfile.ZipFile(archive) as bundle:
        members = bundle.infolist()
    names = set()
    total = 0
    if len(members) > 100_000:
        raise ValueError("Archive has too many members")
    for member in members:
        path = validate_member(member)
        key = str(path).casefold()
        if key in names:
            raise ValueError(f"Duplicate archive destination: {path}")
        names.add(key)
        total += member.file_size
    if total > MAX_EXTRACTED:
        raise ValueError("Archive exceeds the 50 GiB extracted-data budget")
    print(json.dumps({"entries": len(members), "extracted_bytes": total}, indent=2))
    return members


def verify_archive(archive: Path) -> str:
    if archive.stat().st_size != EXPECTED_BYTES:
        raise ValueError(
            "Archive size differs from publisher metadata; keep/resume the partial file"
        )
    checksum = hashlib.md5(usedforsecurity=False)
    with archive.open("rb") as stream:
        while chunk := stream.read(8 * 1024**2):
            checksum.update(chunk)
    actual = checksum.hexdigest()
    if actual != EXPECTED_MD5:
        raise ValueError("Publisher MD5 mismatch; archive is NOT approved for extraction")
    return actual


def extract_archive(archive: Path, destination: Path) -> None:
    members = inspect_archive(archive)
    required = sum(member.file_size for member in members)
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    if shutil.disk_usage(root).free < required + 2 * 1024**3:
        raise ValueError("Insufficient disk space for extraction plus 2 GiB headroom")
    with zipfile.ZipFile(archive) as bundle:
        for member in members:
            path = validate_member(member)
            target = root.joinpath(*path.parts)
            if not target.resolve().is_relative_to(root):
                raise ValueError("Extraction target escapes the dataset directory")
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                raise ValueError(f"Refusing to overwrite existing extracted file: {target}")
            with bundle.open(member) as source, target.open("xb") as output:
                shutil.copyfileobj(source, output, length=1024**2)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--status", action="store_true", help="Report local download progress only")
    parser.add_argument(
        "--extract", action="store_true", help="Extract only after checksum verification"
    )
    args = parser.parse_args()
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    if args.status:
        current = ARCHIVE if ARCHIVE.exists() else PARTIAL
        size = current.stat().st_size if current.exists() else 0
        print(
            json.dumps(
                {
                    "bytes": size,
                    "expected_bytes": EXPECTED_BYTES,
                    "percent": round(100 * size / EXPECTED_BYTES, 3),
                    "verified_receipt": (ARCHIVE.parent / "verified.json").exists(),
                },
                indent=2,
            )
        )
        return
    with acquisition_lock(ARCHIVE.parent):
        if not ARCHIVE.exists():
            curl = shutil.which("curl.exe") or shutil.which("curl")
            if curl is None:
                raise RuntimeError("curl is required for resumable downloads")
            download_archive(curl)
            verify_archive(PARTIAL)
            PARTIAL.rename(ARCHIVE)
        checksum = verify_archive(ARCHIVE)
        inspect_archive(ARCHIVE)
        receipt = {"record": 12525502, "url": URL, "bytes": EXPECTED_BYTES, "md5": checksum}
        (ARCHIVE.parent / "verified.json").write_text(
            json.dumps(receipt, indent=2), encoding="utf-8"
        )
        if args.extract:
            extract_archive(ARCHIVE, ROOT / "dataset/raw")
            print("Extraction complete. Image/label audit is still required in Phase 1.")
        else:
            print(
                "Archive verified. Run again with --extract to extract without overwriting files."
            )


if __name__ == "__main__":
    main()
