$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
Set-Location -LiteralPath $root
$python = Join-Path $root '.venv\Scripts\python.exe'
& $python -m pip check
if ($LASTEXITCODE -ne 0) { throw 'pip check failed' }
& $python -m pytest -q
if ($LASTEXITCODE -ne 0) { throw 'pytest failed' }
& $python -m ruff check ml services scripts tests
if ($LASTEXITCODE -ne 0) { throw 'ruff check failed' }
& $python -m ruff format --check ml services scripts tests
if ($LASTEXITCODE -ne 0) { throw 'ruff format failed' }
& (Join-Path $PSScriptRoot 'npm.ps1') exec -- biome check package.json biome.json apps/web
if ($LASTEXITCODE -ne 0) { throw 'Biome check failed' }
& (Join-Path $PSScriptRoot 'npm.ps1') --prefix apps/web run test
if ($LASTEXITCODE -ne 0) { throw 'Web tests failed' }
& (Join-Path $PSScriptRoot 'npm.ps1') --prefix apps/web run build
if ($LASTEXITCODE -ne 0) { throw 'Web build failed' }
& (Join-Path $PSScriptRoot 'npm.ps1') audit --audit-level=moderate
if ($LASTEXITCODE -ne 0) { throw 'npm audit requires review' }
& $python scripts/check_environment.py
if ($LASTEXITCODE -ne 0) { throw 'Runtime imports or TensorFlow compute failed' }
& $python scripts/dataset.py --status
if ($LASTEXITCODE -ne 0) { throw 'Dataset status inspection failed' }
Write-Output 'Prerequisite checks passed. Dataset verification/extraction and later phase gates are separate.'
