"""Import and compute checks for prerequisites; this does not train a classifier."""

import importlib.metadata
import json
import platform
import sys

import fastapi
import keras
import matplotlib
import numpy
import pandas
import PIL
import sklearn
import tensorflow as tf


def main() -> None:
    result = tf.linalg.matmul(tf.constant([[1.0, 2.0]]), tf.constant([[3.0], [4.0]]))
    if float(result[0, 0]) != 11.0:
        raise RuntimeError("TensorFlow compute smoke check failed")
    versions = {
        "python": platform.python_version(),
        "executable": sys.executable,
        "tensorflow": tf.__version__,
        "keras": keras.__version__,
        "numpy": numpy.__version__,
        "pandas": pandas.__version__,
        "scikit-learn": sklearn.__version__,
        "pillow": PIL.__version__,
        "fastapi": fastapi.__version__,
        "matplotlib": matplotlib.__version__,
        "pytest": importlib.metadata.version("pytest"),
        "gpu_devices": [device.name for device in tf.config.list_physical_devices("GPU")],
        "tensor_compute": "PASS",
        "trained_classifier": False,
    }
    print(json.dumps(versions, indent=2))


if __name__ == "__main__":
    main()
