# Reviewed project skills

Installed 2026-11-01 into `.agents/skills/`, not the user's global skills. Skills become discoverable on the next Codex turn; they can also be read directly now. Sources were discovered using Vercel Labs `skills@1.7.4` (`skills find tensorflow`, `skills find keras`, repository listing), inspected, and copied at exact revisions using Codex's bundled skill installer. No bulk skill packs installed.

| Installed directory | Declared skill | Source commit and path |
| --- | --- | --- |
| react-best-practices | vercel-react-best-practices | vercel-labs/agent-skills @ 1a2c79d4e6c4a2283dc2c614b6538cbe1ed5ca62, skills/react-best-practices |
| composition-patterns | vercel-composition-patterns | same revision, skills/composition-patterns |
| web-design-guidelines | web-design-guidelines | same revision, skills/web-design-guidelines |
| ui-ux-pro-max | ui-ux-pro-max | nextlevelbuilder/ui-ux-pro-max-skill @ 3a13158ff1f32156cbe144108de48eda2ecaed9a, .claude/skills/ui-ux-pro-max |
| tensorflow-deep-learning | tensorflow-deep-learning | mindrally/skills @ 7682ca77710e0971eab4e0ae5dddfa281aea0ba5, tensorflow-deep-learning |

Repository sources:

- https://github.com/vercel-labs/agent-skills
- https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
- https://github.com/mindrally/skills
- Discovery CLI: https://github.com/vercel-labs/skills

## Review outcomes and adaptations

- React/composition frontmatter declares MIT. Vercel repository API did not expose a root license; do not invent one for other files. Preserve original skill metadata/notices.
- UI/UX repository API declares MIT. Its complete skill includes local scripts/data/references (about 3.7 MB), not just SKILL.md. Search uses bundled Python/CSV resources; no model/image API is required. `search.py --help` and a two-result UX query executed successfully.
- Mindrally repository API declares Apache-2.0. This is a THIRD-PARTY TensorFlow/Keras workflow skill, not official TensorFlow, Keras, Vercel, or OpenAI guidance. It covers tf.data, splitting, callbacks, evaluation, and export; current APIs must still be checked against official documentation.
- ML examples are generic templates, not our validated pipeline. Use one consistent checkpoint/early-stop monitor and architecture-specific preprocessing. Keras 3 `.keras` reload differs from SavedModel serving; do not assume load_model reads model.export output.
- Vercel React skills include Next.js/SSR advice; skip that material for the Vite client app. Do not add Next.js, SWR, caching services or authentication just because an example mentions them.
- UI/UX upstream invocation uses `${CLAUDE_PLUGIN_ROOT}`. Here use the actual project skill path, e.g. `python D:/OEC-JEEVAH/.agents/skills/ui-ux-pro-max/scripts/search.py "image upload accessibility" --domain ux --max-results 2`. The search smoke test is a packaging check, NOT browser accessibility validation.
- All output is advisory. Reject clinical-trust claims, unnecessary generated-media APIs, positive-tabindex recommendations, and anything conflicting with privacy/safety constraints.
- Use the installed Codex browser capability for localhost visual/interactive testing in Phase 4; Playwright/axe are installed as complementary automated test tools. No browser skill pack is needed now.

## Reinstallation

With the local npm wrapper and pinned CLI, install from a pinned source URL rather than latest main, selecting exact skills and Codex/project scope. Example:

```powershell
.\scripts\npm.ps1 exec -- skills add https://github.com/vercel-labs/agent-skills/tree/1a2c79d4e6c4a2283dc2c614b6538cbe1ed5ca62 --skill vercel-react-best-practices vercel-composition-patterns web-design-guidelines --agent codex --copy --yes
```

The current install used the bundled helper (download mode, exact revision, `--dest D:/OEC-JEEVAH/.agents/skills`) to avoid unpinned clones and global changes. Reinstall only missing skills; do not overwrite reviewed contents silently. Recheck upstream licensing before redistribution.
