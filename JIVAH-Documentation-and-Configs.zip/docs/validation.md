# Validation evidence

## 2026-11-08 — Longer local training and presentation layout

- Trained a new experimental DenseNet121 head with ImageNet initialization on the existing subject-grouped split for up to 20 epochs, using class weights and best-validation-loss checkpointing. Best validation checkpoint: epoch 19, validation accuracy 69.7%, validation loss 0.742. Artifact and its metadata are local under ignored `artifacts/retrain-head-20261108/`; `scripts/serve.py --experimental` now loads it.
- Evaluated once on the 74-image held-out set: accuracy 59.5%, macro F1 0.395, balanced accuracy 0.401. The previous experimental model recorded 37.8%, 0.271, and 0.311 respectively. The training majority-class baseline is 63.5%, so the new model remains below that accuracy baseline. None of the five Vata test examples were classified correctly; Vata has 25 training examples. This is a small, unreviewed dataset/split and a preliminary classroom demonstration, not evidence of clinical validity or reliable personalized classification. Scores are not calibrated probabilities.
- Updated the prediction layout so the food guide sits below image upload on the left and model scores/research context sit on the right. Raised type size and mobile spacing, increased heading contrast, and stack food cards on narrow screens.
- The live browser uploaded two local held-out images to the loopback API and displayed different leading categories: Kapha (54.0%) for `004_02_00-crop.JPG`, then Pitta (60.7%) for `014_02_00-crop.JPG`. The corresponding Kapha and Pitta food guides appeared in the left panel. API health reported ready. No external upload or persistent upload storage was used.
- After the final layout and serving-path changes, `scripts/check.ps1` passed the Python suite, 9 web tests, TypeScript/build, Ruff, Biome, dependency/runtime checks, and npm audit. Existing Biome CSS specificity warnings and dependency deprecation warnings remain.
- Release status remains experimental and unreviewed. The held-out score is still below the majority baseline, the Vata class is not learned by this checkpoint, and the artifact is intentionally not represented as clinically approved. The local presentation URL is `http://127.0.0.1:5173/`; keep the app runner open while demonstrating.

## 2026-11-08 — Score-selected food guide and local API connection

- Reworked the single-screen interface with a left-aligned editorial header, ink-and-lime contrast, a contrasting research-output panel, ranked three-class score bars, and a capture-conditions guide (even light, focus, centered framing). The result selects the single highest score from the three score entries and displays that class's “Foods to Favor” and “Foods to Limit” reference lists. Exact ties suppress category-specific food suggestions. The static lists are presented as traditional-style educational content, not a personal nutrition plan or medical advice; the card links a Mahidol University traditional-food overview and ICMR-NIN balanced-diet guidance.
- Local API runner started with `python -m scripts.serve --experimental`; `/api/health` returned `{"status":"ok","ready":true}`. A held-out test image (`004_02_00-crop.JPG`) was sent through the Vite `/api/predict` proxy to FastAPI and returned a real model response (Kapha 55.3%, Vata 28.6%, Pitta 16.2%) with the model hash and experimental/low-performance warnings. Request remained on loopback; inference is in-memory.
- Codex browser preview at `http://127.0.0.1:5173/` showed the new layout, capture guide, and `Local model ready`. The browser did not submit the image itself; API proxy integration was checked with the local request above. Automated result-panel behavior is covered by the web test.
- Web tests: 9 passed, including a case where the API label says Vata but Pitta has the highest numeric score; the Pitta guide is selected from the scores. TypeScript and production build passed. Biome check exits successfully with CSS `noDescendingSpecificity` warnings; formatting and accessibility checks pass. `/api/health` returned ready during this validation.
- Limitation: the attached student video’s opening frames showed the project workspace/IDE rather than its prediction page, so the redesign uses the demonstrated project scope as reference and differentiates the current app through its layout, color system, capture guidance, and score interpretation. The experimental classifier remains unreviewed, low-performing, and not clinically validated.

## 2026-11-02 — Research insights box

- Added a result-side insights box that states the highest-scoring research category, explains that scores cannot determine health or personality, and directs users with symptoms or concerns to a qualified healthcare professional. It does not generate personalized medical advice or hide model warnings.
- Browser verification used a synthetic, non-tongue image through the running local API and confirmed the insights and existing experimental/low-performance warnings appeared. This does not validate predictions or detect whether an upload is a tongue photograph. Web tests: 8 passed; production build passed.

## 2026-11-02 — User-requested local experimental model

- The user explicitly requested a working local demo using assumptions in place of the independent review gates. The default approval-required path remains; `--experimental` is an opt-in, explicitly unreviewed research exception. No data or serving approval was fabricated.
- Trained an ImageNet-initialized DenseNet121 with a frozen backbone and trainable three-class head on 347 images for two epochs; validation used 76 images. The best validation-loss checkpoint and honest metadata were saved in ignored `artifacts/experimental-demo/`.
- One held-out test of 74 images from 38 candidate IDs yielded accuracy 28/74 (37.8%), macro F1 0.271 and balanced accuracy 0.311. The majority-class baseline was 47/74 (63.5%); none of five Vata test images was correctly classified. These figures are preliminary and unreliable because the test set is small, candidate IDs and duplicate relationships are not fully verified, and the split is unreviewed. The model is not clinically validated or suitable for diagnosis.
- A real held-out dataset image was selected and submitted through the local browser to the actual loaded model. The app displayed an actual class and scores plus non-diagnostic, unreviewed, and low-performance warnings; the test image was then removed from the browser. No external upload was used.
- Experimental training tests: 6 passed. Screening/manifest/split tests: 21 passed. API tests: 44 passed using synthetic fixtures. Data, identity, privacy, and release review gates remain open.

## 2026-11-02 — Conservative candidate screening

- In response to the user's request to proceed using documented assumptions, added `ml.near_duplicates`: it screens 64-bit difference hashes across different candidate IDs and excludes every image belonging to an ID involved in a flagged pair. This treats similarity as uncertain rather than silently identifying or relabeling people. It does not establish identity, find all duplicates, or approve the data for training.
- Screening the 525-image manifest at distance at most four flagged eight image pairs involving 14 candidate IDs; whole-ID exclusion retained 497 images. The seed-42 provisional split contains 347 training, 76 validation and 74 test images, including five Vata images in each evaluation partition. The screening report and candidate split are in ignored `dataset/manifests/`.
- Focused screening tests: 2 passed. The original unmatched images, label conflicts, interpretation of IDs, privacy/consent, and independent review remain unresolved. Neither the screening nor the user's request is an independent human approval; no approved classifier or real predictions are claimed.
- Independent automated review confirmed the conservative split's IDs, paths, and recorded hashes do not cross partitions, but could not verify person identity or rule out all near-duplicates. Tests for screening, manifest and split: 21 passed. Three real dataset samples, one per class, produced exactly equal training and API preprocessing arrays; this is not model inference or an evaluation of all inputs.

## 2026-11-02 — Verified dataset and initial real-data audit

- The user provided the archive. Publisher size and MD5 matched; `scripts/dataset.py --extract` completed after inspecting 1,715 members (3,718,291,893 uncompressed bytes). A verification receipt is in ignored `dataset/archives/verified.json`. Removed the superseded 330,365,332-byte partial download; the complete archive and the user's Downloads copy remain.
- `ml.manifest` examined the extracted `Crop_images` against the upstream CSV and produced 525 candidate images and 57 issues: 24 unmatched images, seven missing images, eight IDs with conflicting labels and 16 associated images, one ambiguous image mapping and one duplicate-byte issue. These findings overlap; they are not 57 independent excluded images. Its exit code 1 correctly reports unresolved issues.
- A provisional seed-42 candidate-ID split contains 366 training, 78 validation and 81 test images; the validation and test partitions contain only five Vata images each. This is not an approved split and candidate-ID semantics remain unverified.
- A preliminary 64-bit difference-hash comparison of candidate images found five pairs from different candidate IDs and different candidate splits with distance at most four, including pairs with differing class labels. These are candidates for review, not proven duplicates; this simple screen cannot establish identity or detect all near duplicates. Identity, conflicting labels, privacy/consent, and near-duplicate/family review remain open. No approval was fabricated and no real-data training or prediction has been performed.
- The authors' [paper](https://ph01.tci-thaijo.org/index.php/ecticit/article/download/260498/174846/1026620) describes two cameras per patient and original-study consent. The CSV filename prefix consistently equals the CSV ID, supporting its use as a candidate grouping key, but the available material does not establish that IDs are unique and stable across this archive, explain the eight cross-camera class disagreements, or determine the consent scope for secondary use. The paper's cohort counts and this CSV do not fully reconcile; request source clarification instead of guessing.

## 2026-11-02 — Local upload connectivity

- Fixed the missing-model upload path so the API consumes bounded request data before returning 503; the Vite proxy had logged ECONNRESET and returned 502 for a larger upload. A 2 MB synthetic request through the live proxy now returns 503, as intended.
- The web client checks readiness before sending an image, distinguishing an offline API from an unavailable model. Python API tests: 24 passed; web tests: 7 passed; web production build passed. No real-data model has been trained.
- The download remained incomplete at 157,413,964 / 3,694,327,548 bytes (4.261%) when checked. A pretrained ImageNet DenseNet backbone has been cached, but it is not a trained Tri-Dhat classifier. The acquisition, review, training, evaluation and serving approval gates remain open.

## 2026-11-01 - Phase 0 in progress

| Check | Actual result | Status |
| --- | --- | --- |
| `git status --short --branch` | Existing unborn master, no commits | PASS |
| `git remote -v` | No remote | PASS |
| Reference clone and revision | 98021be7aec08d2d5e35b38de09ca7c4f142a3f4 | PASS |
| README/config/source/CSV audit | Tri-Dhat not diseases; 549 rows; repeated IDs | PASS |
| Zenodo API | Version 12525502, 3,694,327,548 bytes, CC-BY-4.0, MD5 recorded | PASS |
| Runtime recovery | Original Node 22.14.0/global npm shim left untouched; local Node 22.23.4/npm 10.9.9 installed and official archive SHA-256 verified | PASS |
| Requested worker models | Luna and Terra rejected by account; unqualified Luna unknown | UNAVAILABLE |
| Hardware | 16,850,198,528 bytes RAM; Intel Iris Xe; disk initially about 174.7 GB free; TensorFlow GPU list empty | PASS, CPU-FIRST |
| Dataset | Background resumable transfer; 25,318,820 / 3,694,327,548 bytes (0.685%) at final snapshot; checksum/extraction incomplete | PENDING |
| Dependencies | Python venv and exact requirements.lock.txt; npm package-lock.json; repeat setup and imports pass | PASS |
| Skills | Five project-local, revision-pinned skills installed; UI/UX search helper runs with local data | PASS |
| Browser | No runnable web UI yet | N/A |

No model training, accuracy, browser checks, or real predictions claimed.

## Executed prerequisite checks

All commands run from `D:/OEC-JEEVAH` on Windows x64 / Python 3.13.1.

| Command | Observed result |
| --- | --- |
| `./scripts/setup.ps1` | npm ci reconstructs dependency tree; all exact Python pins installed; pip check passes; exit 0 |
| `./scripts/check.ps1` | Entire prerequisite check entrypoint exits 0; acquisition remains a separate gate |
| `./.venv/Scripts/python.exe -m pip check` | No broken requirements |
| `./.venv/Scripts/python.exe -m pytest -q` | 7 tests and 10 subtests pass; synthetic archive fixtures only |
| `./.venv/Scripts/python.exe -m ruff check scripts tests` | All checks pass |
| `./.venv/Scripts/python.exe -m ruff format --check scripts tests` | 4 files formatted |
| `./scripts/npm.ps1 exec -- biome check package.json biome.json` | 2 files checked, no fixes/errors |
| `./scripts/npm.ps1 audit --audit-level=moderate` | Zero npm vulnerabilities; not a claim of a Python CVE audit |
| npm wrapper tool version checks | Vite 8.3.5, TypeScript 6.0.3, Vitest 5.0.5 execute on local Node 22.23.4 |
| React/Zod import check | React 19.3.1 imports; schema safeParse smoke check true |
| `./.venv/Scripts/python.exe scripts/check_environment.py` | TensorFlow 2.21.0, Keras 3.15.1, NumPy 2.5.4, pandas 3.1.0, sklearn 1.9.1, Pillow 12.3.0, FastAPI 0.162.0 and Matplotlib 3.11.2 import; matrix multiply returns expected 11 |
| UI/UX helper help + two-result accessibility search | Runs without missing scripts/data or external dependency installation |
| PowerShell parser for setup/check/npm scripts | No parse errors |
| `git check-ignore` for reference/data/models/venv/tools/node_modules | All expected paths ignored |
| `git status`, `git ls-files`, `git remote -v` | Unborn master; nothing tracked/staged; no remotes; no commits created |

TensorFlow reports expected native-Windows GPU unavailability and oneDNN rounding notices. CPU computation passes; no hardware acceleration or trained classifier is claimed.

## Download state and recovery

- Background launcher PID at final snapshot: **13320**, confirmed alive; its curl child is performing the resumable transfer. PID is only an observation, not a durable identity or guarantee after reboot.
- Source connection has been slow and interrupted (curl codes 56/18). The current command retries errors, retains `.zip.part`, and only approves/renames after exact size + publisher MD5 verification. No verified receipt exists yet.
- Status: `./.venv/Scripts/python.exe scripts/dataset.py --status`.
- Logs (ignored): `artifacts/dataset-download.log` and `artifacts/dataset-download-error.log`.
- If the transfer exits, inspect logs and rerun `./.venv/Scripts/python.exe scripts/dataset.py --extract`. Do not run two downloaders simultaneously. No automatic reboot recovery or notification is configured.
- Extraction is NOT complete. Real image readability, archive counts, label joins, subject grouping and training remain unvalidated.

**Historical snapshot:** Phase 0 had not fully passed at this point. The following entry supersedes its process, phase, and browser status.

## 2026-11-01 — Phase 1 preparation while acquisition continues

- At the user's direction, started Phase 1 tooling without claiming that Phase 0 has passed. Archive acquisition remains incomplete; full checksum verification and extraction have not occurred. `scripts/dataset.py --status` is the authoritative current progress, not a stale percentage or PID.
- The downloader now has a cross-process acquisition lock and resumes interrupted transfers, with a bounded number of stalled retries. Check ignored `artifacts/dataset-download-v2.log` and `artifacts/dataset-download-v2-error.log` for the active attempt. No automatic reboot recovery is configured.
- A partial HTTP-range central-directory snapshot, not the verified full archive, provisionally indicates 567 crop images, 567 ROI masks, 24 crop stems without CSV labels, seven CSV stems missing from the crop index, and one duplicate crop stem. The source CSV has eight candidate IDs associated with conflicting class labels. These observations require verification against the fully downloaded archive and expert/source review; candidate-ID semantics are unverified. Never resolve conflicts by guessing.
- `ml.manifest` and `ml.split` were developed and tested on synthetic data only. Auditing quarantines discrepancies; splitting groups candidate IDs and exact duplicate hashes transitively. Neither constitutes an approved real-data split or validates person identity. Manifest reports explicitly set training readiness to false.
- `scripts.reference_audit` generates an ignored, research-only static preview from the CSV and unverified index. Codex's in-app localhost browser displayed the disclaimer and summary; 375px and 1280px viewport checks found no horizontal overflow. This is not a model, disease diagnosis, or the final upload interface.
- Full `scripts/check.ps1` passed: 31 tests and 10 subtests, Ruff lint/format, Biome, `pip check`, npm audit (zero vulnerabilities), and CPU TensorFlow compute. This is not model training or a real-data validation.
- Two requested Terra 6.1 high worker launches were rejected as unsupported by this account; two default-model workers completed the independent manifest and split tasks. No Terra or Luna override is claimed to have run.

**Gates remain open:** Phase 0 requires a complete verified and safely extracted archive. Phase 1 requires real-image auditing, discrepancy resolution, privacy/consent and candidate-ID review, and an independently checked leakage-safe split. No model has been trained.

## 2026-11-02 — Model tooling, API, and web preparation

- The user requested work on later phases in parallel. Added DenseNet training, split-bound review assertion, held-out evaluation and provenance tooling; `configs/phase2.md` records its contract and limitations. The only training performed was a synthetic one-batch test, not training on the reference dataset or an approved artifact.
- Added a local FastAPI inference path. It requires matching model, metadata, test-evaluation and independent local approval files; the approval is an unauthenticated human assertion, not proof. Without them `/api/health` reports `ready: false` and `/api/predict` returns 503. It limits requests and image dimensions, checks image format, runs TensorFlow-compatible preprocessing in memory, validates model output, and returns research-only class labels. API tests use synthetic models only.
- Added the React/Vite interface. Codex in-app browser tested the real local frontend and API: selected a generated non-tongue PNG, observed the preview, submitted it, saw the model-unavailable response, and removed it. At 375px and 1280px there was no horizontal overflow. No real-image prediction, disease diagnosis or real-model integration was tested.
- `scripts/check.ps1` passed: 60 Python tests plus 10 subtests, six frontend tests, Ruff and Biome, TypeScript/Vite build, `pip check`, npm audit and TensorFlow CPU check. Python reported 661 dependency deprecation warnings, notably Keras/NumPy, gast and Starlette; monitor during dependency maintenance. No actual model quality metrics were produced.
- Source GitHub releases had no attached model weight assets at inspection. The dataset transfer was still incomplete (2.9% at the recorded check), with no verified receipt or extraction; use `scripts/dataset.py --status` for current progress. The already observed candidate-ID conflicts and filename discrepancies remain unresolved.

**Acceptance remains incomplete:** verify and extract the complete archive; audit and resolve labels/identities/duplicates and privacy; obtain a reviewed grouped split; train and independently evaluate; review and configure actual artifact release approval; then retest real local image-to-model inference and the final browser journey. No remote Git repository or deployment was created.

## 2026-11-01 — Phase 2 tooling preparation

- Implemented research training and split-bound evaluation tooling only. A synthetic
  DenseNet model underwent a single training batch, preprocessing comparison and
  `.keras` reload test; it is not a real trained or approved artifact.
- Focused tests: 5 passed. The full suite before the final added synthetic training
  assertion: 48 passed and 10 subtests passed. Ruff lint and format checks passed;
  npm audit reported zero vulnerabilities. Keras/NumPy deprecation warnings remain.
- Latest `scripts/dataset.py --status` snapshot: 83,444,300 / 3,694,327,548 bytes;
  verified receipt false. No checksum-verified extraction or real-data evaluation.
- Acquisition, data and identity review, crop/near-duplicate verification, actual
  training, independent holdout evaluation, model approval and API release remain
  pending. The local approval file is only a review assertion, not authentication.
- See `configs/phase2.md` for usage, preprocessing and the distinction between
  training metadata, metrics, and the API's separate release evidence.
