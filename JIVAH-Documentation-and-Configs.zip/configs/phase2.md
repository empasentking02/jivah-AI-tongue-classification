# Phase 2 research tooling

At the user's explicit request, the `--experimental` training and evaluation flags
allow a local research demo using an unreviewed split without creating an approval.
The output remains experimental, not a reviewed or clinically validated release.
Existing approval-gated behavior remains the default.

No data or model has been approved by this file. Before real training, complete the
acquisition, consent/privacy, identity, original/crop and near-duplicate reviews and
independently check the resulting split. A reviewer then records an approval JSON
outside Git containing `approved` (true), `split_sha256` (SHA-256 of the exact split
CSV), `reviewer` (name) and `evidence` (reference to the actual review). This is a
local assertion, not authenticated proof; its trustworthiness requires human review.

Training: `python -m ml.train --split PATH --image-root PATH --approval PATH --output artifacts/RUN`.
It uses no pretrained download unless `--imagenet` is explicitly supplied. Without it,
the frozen backbone is randomly initialized and is only an experimental baseline,
not an approved inference model. Outputs are a best-validation-loss `.keras` checkpoint
and `metadata.json`. Output directories must not already exist.

After freezing choices on validation, evaluation uses `python -m ml.evaluate --split PATH
--image-root PATH --approval PATH --model artifacts/RUN/best.keras --metadata
artifacts/RUN/metadata.json --partition test --output artifacts/RUN/test.json`. The same
command supports `--partition validation`. The user must enforce a single final holdout
evaluation and no test-driven model selection; this CLI cannot enforce those policies
across runs or copies. Reports do not grant release approval.

The model accepts batches of RGB float32 `[N,224,224,3]` values in `[0,255]` and
embeds DenseNet normalization. Decode to RGB and resize using TensorFlow bilinear
`tf.image.resize(..., antialias=False)` without aspect-ratio preservation. The output
is three softmax scores ordered 0=Pitta, 1=Vata, 2=Kapha, not diagnoses or calibrated
probabilities. TensorFlow's decoder supports JPEG, PNG, BMP and GIF; unsupported source
formats must be audited and converted deliberately before creating an approved split.

The sidecar includes `model_sha256`, `split_sha256`, `config_sha256`, `approval_sha256`,
`preprocessing`, `labels`, `input`, `output`, `config`, `weights`, TensorFlow, Keras
and Python versions, and training history. It is provenance, not an authenticated model
approval or evaluation certificate. Serving must independently verify the model hash,
contract, explicit model approval and appropriate evaluation evidence; otherwise it
must remain unavailable. Exact preprocessing/serialization parity must be validated
for any approved model and API before release.

Serving uses the training `metadata.json`, the actual held-out test report, and a
separate strict human-authored release approval JSON with `approved` (true),
`model_version`, `model_sha256`, `split_sha256`, `metadata_sha256`,
`evaluation_sha256`, `reviewer`, and `evidence`. The four hashes must match the
reviewed files and split recorded in metadata. The test report's `subject_count`
is a candidate-ID count, not independently verified identity. Do not create an
approval until data, test results, preprocessing parity, and intended research use
have actually been reviewed. This local JSON is an assertion, not authenticated proof.
