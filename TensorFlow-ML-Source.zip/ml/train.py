"""Research-only training, gated on independent data approval."""

import argparse
import csv
import hashlib
import json
import math
import platform
from collections import Counter
from pathlib import Path, PureWindowsPath

from ml.split import FIELDS, LABELS, SPLITS, validate_rows

PREPROCESSING = "rgb-bilinear-224-densenet-v1"


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_approved_split(split_path, image_root, approval_path=None, *, experimental=False):
    split_path, image_root = Path(split_path), Path(image_root).resolve(strict=True)
    if experimental:
        if approval_path is not None:
            raise ValueError("Experimental mode must not claim a data approval")
    else:
        if approval_path is None:
            raise ValueError("Independent data/identity approval for this exact split is required")
        approval = json.loads(Path(approval_path).read_text(encoding="utf-8"))
        if (
            approval.get("approved") is not True
            or approval.get("split_sha256") != sha256(split_path)
            or not isinstance(approval.get("reviewer"), str)
            or not approval["reviewer"].strip()
            or not isinstance(approval.get("evidence"), str)
            or not approval["evidence"].strip()
        ):
            raise ValueError("Independent data/identity approval for this exact split is required")
    with split_path.open(encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source, strict=True)
        if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError("Invalid split header")
        if set(reader.fieldnames) != set(FIELDS) | {"split"}:
            raise ValueError("Invalid split columns")
        records = list(reader)
    if any(set(row) != set(FIELDS) | {"split"} for row in records):
        raise ValueError("Malformed split rows")
    rows = validate_rows([{key: row.get(key) for key in FIELDS} for row in records])
    subjects, digests, paths = {}, {}, {}
    for row, record in zip(rows, records):
        split = record["split"]
        if split not in SPLITS:
            raise ValueError("Invalid split assignment")
        for index, key in ((subjects, row["subject_id"]), (digests, row["sha256"])):
            if index.setdefault(key, (split, row["label"])) != (split, row["label"]):
                raise ValueError("Subject or duplicate crosses splits or has conflicting labels")
        raw = row["path"]
        if (
            Path(raw).is_absolute()
            or PureWindowsPath(raw).is_absolute()
            or PureWindowsPath(raw).drive
        ):
            raise ValueError("Image paths must be relative")
        path = (image_root / raw).resolve(strict=True)
        if not path.is_relative_to(image_root) or not path.is_file():
            raise ValueError("Image path escapes image root")
        if path in paths and paths[path] != (split, row["label"]):
            raise ValueError("Image path crosses splits or has conflicting labels")
        paths[path] = (split, row["label"])
        if sha256(path) != row["sha256"]:
            raise ValueError("Image content does not match split hash")
        row.update(split=split, absolute_path=str(path))
    for split in SPLITS:
        if {row["label"] for row in rows if row["split"] == split} != set(LABELS):
            raise ValueError(f"Missing class coverage in {split}")
    return rows


def class_weights(rows):
    counts = Counter(row["label"] for row in rows if row["split"] == "train")
    if set(counts) != set(LABELS):
        raise ValueError("Training split must contain all classes")
    return {int(label): sum(counts.values()) / (3 * count) for label, count in counts.items()}


def load_config(path):
    config = json.loads(Path(path).read_text(encoding="utf-8"))
    if set(config) != {"seed", "batch_size", "epochs", "learning_rate", "patience"}:
        raise ValueError("Invalid configuration fields")
    for key in ("seed", "batch_size", "epochs", "patience"):
        if type(config[key]) is not int or config[key] < (0 if key in {"seed", "patience"} else 1):
            raise ValueError(f"Invalid {key}")
    rate = config["learning_rate"]
    if (
        isinstance(rate, bool)
        or not isinstance(rate, (float, int))
        or not math.isfinite(rate)
        or rate <= 0
    ):
        raise ValueError("Invalid learning_rate")
    return config


def make_dataset(rows, split, config, training=False):
    import tensorflow as tf

    selected = [row for row in rows if row["split"] == split]
    paths = [row["absolute_path"] for row in selected]
    labels = [int(row["label"]) for row in selected]
    dataset = tf.data.Dataset.from_tensor_slices((paths, labels))
    if training:
        dataset = dataset.shuffle(len(paths), seed=config["seed"], reshuffle_each_iteration=True)

    def decode(path, label):
        image = tf.io.decode_image(tf.io.read_file(path), channels=3, expand_animations=False)
        image.set_shape([None, None, 3])
        return tf.image.resize(image, [224, 224], method="bilinear", antialias=False), label

    return (
        dataset.map(decode, num_parallel_calls=1, deterministic=True)
        .batch(config["batch_size"])
        .prefetch(1)
    )


def build_model(weights=None):
    import tensorflow as tf

    inputs = tf.keras.Input(shape=(224, 224, 3), dtype="float32", name="rgb_pixels")
    normalized = tf.keras.layers.Rescaling(1 / 255.0)(inputs)
    normalized = tf.keras.layers.Normalization(
        mean=[0.485, 0.456, 0.406], variance=[0.229**2, 0.224**2, 0.225**2]
    )(normalized)
    backbone = tf.keras.applications.DenseNet121(include_top=False, weights=weights, pooling="avg")
    backbone.trainable = False
    scores = tf.keras.layers.Dense(3, activation="softmax", name="tri_dhat_scores")(
        backbone(normalized, training=False)
    )
    return tf.keras.Model(inputs, scores, name="tri_dhat_densenet121")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--split", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--approval", type=Path)
    parser.add_argument("--experimental", action="store_true")
    parser.add_argument("--config", type=Path, default=Path("configs/train.json"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--imagenet", action="store_true", help="Permit ImageNet weights download")
    args = parser.parse_args(argv)
    try:
        config = load_config(args.config)
        rows = load_approved_split(
            args.split, args.image_root, args.approval, experimental=args.experimental
        )
        output = args.output.resolve()
        if not output.is_relative_to(Path("artifacts").resolve()) or output.exists():
            raise ValueError("Output must be a new directory inside ignored artifacts/")
        import tensorflow as tf

        tf.keras.utils.set_random_seed(config["seed"])
        tf.config.experimental.enable_op_determinism()
        model = build_model(weights="imagenet" if args.imagenet else None)
        model.compile(
            optimizer=tf.keras.optimizers.Adam(config["learning_rate"]),
            loss="sparse_categorical_crossentropy",
            metrics=["accuracy"],
        )
        output.mkdir(parents=True)
        model_path = output / "best.keras"
        history = model.fit(
            make_dataset(rows, "train", config, training=True),
            validation_data=make_dataset(rows, "validation", config),
            epochs=config["epochs"],
            class_weight=class_weights(rows),
            callbacks=[
                tf.keras.callbacks.ModelCheckpoint(
                    model_path, monitor="val_loss", save_best_only=True
                ),
                tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=config["patience"]),
            ],
        )
        metadata = {
            "research_only": True,
            "experimental": args.experimental,
            "labels": LABELS,
            "preprocessing": PREPROCESSING,
            "input": {
                "shape": [None, 224, 224, 3],
                "dtype": "float32",
                "range": [0, 255],
                "color": "RGB",
            },
            "output": "softmax scores; not calibrated probabilities or diagnoses",
            "model_sha256": sha256(model_path),
            "split_sha256": sha256(args.split),
            "config_sha256": sha256(args.config),
            "approval_sha256": None if args.experimental else sha256(args.approval),
            "config": config,
            "weights": "imagenet" if args.imagenet else "none",
            "tensorflow": tf.__version__,
            "keras": tf.keras.__version__,
            "python": platform.python_version(),
            "history": {
                key: [float(value) for value in values] for key, values in history.history.items()
            },
        }
        (output / "metadata.json").write_text(
            json.dumps(metadata, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
    except (ValueError, OSError, csv.Error) as error:
        parser.exit(2, f"error: {error}\n")


if __name__ == "__main__":
    main()
