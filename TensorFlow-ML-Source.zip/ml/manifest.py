"""Audit extracted images against upstream Tri-Dhat labels."""

import argparse
import csv
import hashlib
import json
import warnings
from collections import defaultdict
from pathlib import Path, PureWindowsPath

from PIL import Image, UnidentifiedImageError

LABELS = {"0": "Pitta", "1": "Vata", "2": "Kapha"}
COLUMNS = ("path", "subject_id", "camera", "label", "label_name", "width", "height", "sha256")
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
SUBJECT_NOTICE = (
    "subject_id is the upstream CSV ID, a candidate grouping key only; "
    "its meaning as a unique person is unverified."
)


def audit(image_root: Path, labels_path: Path) -> tuple[list[dict], dict]:
    """Return accepted records and a quarantine report without moving files."""
    image_root = image_root.resolve(strict=True)
    if not image_root.is_dir():
        raise ValueError("Image root must be a directory")
    issues = []

    def quarantine(reason: str, **details: object) -> None:
        issues.append({"reason": reason, **details})

    mappings = defaultdict(list)
    subject_labels = defaultdict(set)
    with labels_path.open(encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source, strict=True)
        required = {"Filename", "ID", "Camera", "Class"}
        if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError("CSV header is missing or contains duplicate columns")
        if not required.issubset(reader.fieldnames):
            raise ValueError("CSV must contain Filename, ID, Camera, and Class columns")
        for line, row in enumerate(reader, start=2):
            name = row.get("Filename") or ""
            subject = row.get("ID") or ""
            camera = row.get("Camera") or ""
            label = row.get("Class") or ""
            safe_name = (
                bool(name)
                and name == name.strip()
                and name not in {".", ".."}
                and "/" not in name
                and "\\" not in name
                and not PureWindowsPath(name).drive
                and ":" not in name
                and not name.endswith((".", " "))
            )
            valid = (
                safe_name
                and subject.isascii()
                and subject.isdecimal()
                and camera in {"0", "1"}
                and label in LABELS
                and None not in row
                and all(value is not None for value in row.values())
            )
            if not valid:
                quarantine("invalid_csv_row", line=line, filename=name)
            if safe_name:
                if subject.isascii() and subject.isdecimal():
                    subject = str(int(subject))
                mappings[name.casefold()].append((line, name, subject, camera, label, valid))
            if subject.isascii() and subject.isdecimal() and label in LABELS:
                subject_labels[str(int(subject))].add(label)

    conflicting_subjects = {
        subject for subject, values in subject_labels.items() if len(values) > 1
    }
    for subject in sorted(conflicting_subjects):
        quarantine(
            "conflicting_candidate_id_labels",
            subject_id=subject,
            labels=sorted(subject_labels[subject]),
        )
    if not mappings:
        quarantine("no_usable_csv_mappings")

    images = defaultdict(list)
    excluded = []
    for path in sorted(
        image_root.rglob("*"), key=lambda item: item.relative_to(image_root).as_posix()
    ):
        relative = path.relative_to(image_root).as_posix()
        if path.is_symlink():
            quarantine("symlink", path=relative)
        elif path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES:
            if any(
                part.casefold() in {"roi_images", "mask", "masks"}
                for part in path.relative_to(image_root).parts[:-1]
            ):
                excluded.append({"path": relative, "role": "roi_not_photograph"})
                continue
            images[path.stem.casefold()].append(path)

    if not images:
        quarantine("no_candidate_images")

    candidates = []
    for key in sorted(set(mappings) | set(images)):
        rows = mappings.get(key, [])
        paths = images.get(key, [])
        if not rows:
            for path in paths:
                quarantine("unmatched_image", path=path.relative_to(image_root).as_posix())
            continue
        if len(rows) != 1:
            quarantine(
                "duplicate_csv_mapping",
                filenames=sorted(row[1] for row in rows),
                lines=sorted(row[0] for row in rows),
            )
        if not paths:
            quarantine("missing_image", filenames=sorted(row[1] for row in rows))
        elif len(paths) != 1:
            quarantine(
                "ambiguous_image_mapping",
                paths=sorted(path.relative_to(image_root).as_posix() for path in paths),
            )
        if len(rows) != 1 or len(paths) != 1 or not rows[0][5]:
            continue
        _, name, subject, camera, label, _ = rows[0]
        path = paths[0]
        relative = path.relative_to(image_root).as_posix()
        if subject in conflicting_subjects:
            quarantine("conflicting_candidate_id_image", path=relative, subject_id=subject)
            continue
        parts = path.relative_to(image_root).parts
        if (
            len(parts) >= 3
            and parts[-3].casefold() == "crop_images"
            and parts[-2] != camera.zfill(2)
        ):
            quarantine("camera_directory_mismatch", path=relative, camera=camera)
            continue
        if path.stem != name:
            quarantine("filename_case_mismatch", path=relative, filename=name)
            continue
        try:
            digest = hashlib.sha256()
            with path.open("rb") as source:
                for chunk in iter(lambda: source.read(1024 * 1024), b""):
                    digest.update(chunk)
            with warnings.catch_warnings():
                warnings.simplefilter("error", Image.DecompressionBombWarning)
                with Image.open(path) as image:
                    image.verify()
                with Image.open(path) as image:
                    image.load()
                    width, height = image.size
            candidates.append(
                dict(
                    zip(
                        COLUMNS,
                        (
                            relative,
                            subject,
                            camera,
                            label,
                            LABELS[label],
                            width,
                            height,
                            digest.hexdigest(),
                        ),
                        strict=True,
                    )
                )
            )
        except (
            OSError,
            ValueError,
            UnidentifiedImageError,
            Image.DecompressionBombWarning,
            Image.DecompressionBombError,
        ) as error:
            quarantine("invalid_image", path=relative, error=type(error).__name__)

    hashes = defaultdict(list)
    for record in candidates:
        hashes[record["sha256"]].append(record["path"])
    accepted_paths = {record["path"] for record in candidates}
    for paths in images.values():
        for path in paths:
            relative = path.relative_to(image_root).as_posix()
            if relative in accepted_paths:
                continue
            try:
                with path.open("rb") as source:
                    digest = hashlib.file_digest(source, "sha256").hexdigest()
                hashes[digest].append(relative)
            except OSError as error:
                quarantine("unreadable_image", path=relative, error=type(error).__name__)
    accepted = []
    duplicate_hashes = set()
    for digest, paths in sorted(hashes.items()):
        if len(paths) > 1:
            duplicate_hashes.add(digest)
            quarantine("duplicate_image_bytes", sha256=digest, paths=sorted(paths))
    accepted.extend(record for record in candidates if record["sha256"] not in duplicate_hashes)
    accepted.sort(key=lambda record: record["path"])
    issues.sort(key=lambda item: json.dumps(item, sort_keys=True, ensure_ascii=False))
    return accepted, {
        "subject_id_notice": SUBJECT_NOTICE,
        "accepted_count": len(accepted),
        "issue_count": len(issues),
        "quarantine": issues,
        "excluded_count": len(excluded),
        "excluded": excluded,
        "training_ready": False,
        "archive_notice": "Archive layout and contents remain unverified until checksum and extraction; audit alone cannot establish training readiness.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image_root", type=Path)
    parser.add_argument("labels_csv", type=Path)
    parser.add_argument("manifest_csv", type=Path)
    parser.add_argument("report_json", type=Path)
    args = parser.parse_args()
    root = args.image_root.resolve()
    outputs = [args.manifest_csv.resolve(), args.report_json.resolve()]
    if (
        outputs[0] == outputs[1]
        or any(output.is_relative_to(root) for output in outputs)
        or args.labels_csv.resolve() in outputs
    ):
        parser.error("Outputs must be distinct and outside the image root and input CSV")
    try:
        records, report = audit(args.image_root, args.labels_csv)
        with args.manifest_csv.open("w", encoding="utf-8", newline="") as destination:
            writer = csv.DictWriter(destination, fieldnames=COLUMNS, lineterminator="\n")
            writer.writeheader()
            writer.writerows(records)
        with args.report_json.open("w", encoding="utf-8", newline="\n") as destination:
            json.dump(report, destination, indent=2, ensure_ascii=False)
            destination.write("\n")
    except (OSError, ValueError, csv.Error) as error:
        parser.exit(2, f"Audit failed: {error}\n")
    return 1 if report["issue_count"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
