"""Research-only data preparation."""
