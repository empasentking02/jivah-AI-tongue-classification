"""Evaluate a verified training artifact on an approved, untouched split."""

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import (
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
)

from ml.split import LABELS
from ml.train import PREPROCESSING, load_approved_split, make_dataset, sha256


def evaluate(model, dataset, rows, split):
    expected = np.array([int(row["label"]) for row in rows if row["split"] == split])
    scores = np.asarray(model.predict(dataset, verbose=0))
    if (
        scores.shape != (len(expected), 3)
        or not np.isfinite(scores).all()
        or (scores < 0).any()
        or (scores > 1).any()
        or not np.allclose(scores.sum(axis=1), 1, atol=1e-5)
    ):
        raise ValueError("Invalid model scores")
    predictions = scores.argmax(axis=1)
    train_counts = np.bincount(
        [int(row["label"]) for row in rows if row["split"] == "train"], minlength=3
    )
    majority = int(train_counts.argmax())
    return {
        "research_only": True,
        "split": split,
        "labels": LABELS,
        "count": len(expected),
        "subject_count": len({row["subject_id"] for row in rows if row["split"] == split}),
        "macro_f1": float(
            f1_score(expected, predictions, labels=[0, 1, 2], average="macro", zero_division=0)
        ),
        "balanced_accuracy": float(balanced_accuracy_score(expected, predictions)),
        "confusion_matrix": confusion_matrix(expected, predictions, labels=[0, 1, 2]).tolist(),
        "per_class": classification_report(
            expected,
            predictions,
            labels=[0, 1, 2],
            target_names=list(LABELS.values()),
            output_dict=True,
            zero_division=0,
        ),
        "majority_class_from_train": majority,
        "majority_baseline_accuracy": float(np.mean(expected == majority)),
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--split", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--approval", type=Path)
    parser.add_argument("--experimental", action="store_true")
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--partition", choices=["validation", "test"], required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        metadata = json.loads(args.metadata.read_text(encoding="utf-8"))
        if (
            metadata.get("model_sha256") != sha256(args.model)
            or metadata.get("split_sha256") != sha256(args.split)
            or metadata.get("experimental", False) != args.experimental
            or (
                metadata.get("approval_sha256") is not None
                if args.experimental
                else args.approval is None
                or metadata.get("approval_sha256") != sha256(args.approval)
            )
            or metadata.get("preprocessing") != PREPROCESSING
            or metadata.get("labels") != LABELS
        ):
            raise ValueError("Model, split, approval, or contract metadata mismatch")
        output = args.output.resolve()
        if not output.is_relative_to(Path("artifacts").resolve()) or output.exists():
            raise ValueError("Evaluation output must be a new file inside ignored artifacts/")
        rows = load_approved_split(
            args.split, args.image_root, args.approval, experimental=args.experimental
        )
        import tensorflow as tf

        model = tf.keras.models.load_model(args.model, compile=False)
        if model.input_shape != (None, 224, 224, 3) or model.output_shape != (None, 3):
            raise ValueError("Model shape does not match contract")
        report = evaluate(
            model, make_dataset(rows, args.partition, metadata["config"]), rows, args.partition
        )
        report.update(model_sha256=metadata["model_sha256"], split_sha256=metadata["split_sha256"])
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("x", encoding="utf-8") as destination:
            json.dump(report, destination, indent=2, allow_nan=False)
            destination.write("\n")
    except (ValueError, OSError, csv.Error, KeyError) as error:
        parser.exit(2, f"error: {error}\n")


if __name__ == "__main__":
    main()
