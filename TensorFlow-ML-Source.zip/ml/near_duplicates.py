"""Screen candidate photographs and conservatively exclude similar case groups."""

import argparse
import csv
import json
from pathlib import Path

from PIL import Image

from ml.split import FIELDS, read_manifest


def difference_hash(image):
    pixels = list(image.convert("L").resize((9, 8)).get_flattened_data())
    return sum(
        (pixels[row * 9 + column] > pixels[row * 9 + column + 1]) << (row * 8 + column)
        for row in range(8)
        for column in range(8)
    )


def screen(rows, hashes, threshold):
    matches = []
    excluded = set()
    for index, left in enumerate(rows):
        for other in range(index + 1, len(rows)):
            right = rows[other]
            if left["subject_id"] == right["subject_id"]:
                continue
            distance = (hashes[index] ^ hashes[other]).bit_count()
            if distance <= threshold:
                excluded.update((left["subject_id"], right["subject_id"]))
                matches.append(
                    {
                        "left": left["path"],
                        "right": right["path"],
                        "left_subject": left["subject_id"],
                        "right_subject": right["subject_id"],
                        "distance": distance,
                    }
                )
    return [row for row in rows if row["subject_id"] not in excluded], matches, excluded


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("image_root", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("report", type=Path)
    parser.add_argument("--threshold", type=int, default=4, choices=range(65))
    args = parser.parse_args()
    root = args.image_root.resolve(strict=True)
    paths = [args.manifest.resolve(), args.output.resolve(), args.report.resolve()]
    if len(set(paths)) != len(paths) or any(path.is_relative_to(root) for path in paths):
        parser.error("Input and output files must be distinct and outside the image root")
    rows = read_manifest(args.manifest)
    hashes = []
    for row in rows:
        path = (root / row["path"]).resolve(strict=True)
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError("Image path escapes the image root")
        with Image.open(path) as image:
            hashes.append(difference_hash(image))
    retained, matches, excluded = screen(rows, hashes, args.threshold)
    with args.output.open("w", encoding="utf-8", newline="") as destination:
        writer = csv.DictWriter(destination, fieldnames=FIELDS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(retained)
    report = {
        "method": "64-bit difference hash; low distance is a screening flag, not proof",
        "threshold": args.threshold,
        "input_images": len(rows),
        "retained_images": len(retained),
        "excluded_candidate_ids": sorted(excluded),
        "candidate_pairs": matches,
        "training_ready": False,
        "limitations": "Does not establish identity or detect all near-duplicates.",
    }
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {key: report[key] for key in ("input_images", "retained_images", "training_ready")}
        )
    )


if __name__ == "__main__":
    main()
