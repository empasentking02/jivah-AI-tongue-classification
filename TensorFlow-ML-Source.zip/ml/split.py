"""Leakage-safe, research-only grouped stratified manifest splitting."""

import argparse
import csv
import hashlib
import json
import math
import random
import re
from collections import defaultdict
from pathlib import Path

FIELDS = ("path", "subject_id", "camera", "label", "label_name", "width", "height", "sha256")
LABELS = {"0": "Pitta", "1": "Vata", "2": "Kapha"}
SPLITS = ("train", "validation", "test")


def read_manifest(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source)
        if reader.fieldnames is None or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError("Manifest must have unique columns")
        if set(reader.fieldnames) != set(FIELDS):
            raise ValueError(f"Manifest columns must be exactly: {', '.join(FIELDS)}")
        rows = list(reader)
    return validate_rows(rows)


def validate_rows(rows):
    validated = []
    for line, original in enumerate(rows, 2):
        if set(original) != set(FIELDS) or any(
            not isinstance(value, str) for value in original.values()
        ):
            raise ValueError(f"Malformed row at line {line}")
        row = dict(original)
        if any(not value.strip() for value in row.values()):
            raise ValueError(f"Missing field at line {line}")
        if row["subject_id"] != row["subject_id"].strip():
            raise ValueError(f"Invalid subject_id at line {line}")
        if row["label"] not in LABELS or row["label_name"] != LABELS[row["label"]]:
            raise ValueError(f"Invalid label or label_name at line {line}")
        if not re.fullmatch(r"[0-9a-fA-F]{64}", row["sha256"]):
            raise ValueError(f"Invalid sha256 at line {line}")
        row["sha256"] = row["sha256"].lower()
        validated.append(row)
    if not validated:
        raise ValueError("Manifest is empty")
    return validated


def split_manifest(rows, seed=42, ratios=(0.7, 0.15, 0.15)):
    rows = validate_rows(rows)
    if len(ratios) != 3 or any(not math.isfinite(value) or value <= 0 for value in ratios):
        raise ValueError("Ratios must contain three finite positive values")
    if not math.isclose(sum(ratios), 1, rel_tol=0, abs_tol=1e-9):
        raise ValueError("Ratios must sum to 1")
    parents, subject_labels, hash_subjects, hash_labels = {}, {}, {}, {}

    def find(subject):
        while parents[subject] != subject:
            parents[subject] = parents[parents[subject]]
            subject = parents[subject]
        return subject

    for row in rows:
        subject, label, digest = row["subject_id"], row["label"], row["sha256"]
        parents.setdefault(subject, subject)
        if subject in subject_labels and subject_labels[subject] != label:
            raise ValueError(f"Conflicting labels for subject {subject!r}")
        subject_labels[subject] = label
        if digest in hash_labels and hash_labels[digest] != label:
            raise ValueError(f"Conflicting labels for duplicate sha256 {digest}")
        hash_labels[digest] = label
        if digest in hash_subjects:
            parents[find(subject)] = find(hash_subjects[digest])
        else:
            hash_subjects[digest] = subject

    groups = defaultdict(list)
    for subject in sorted(parents):
        groups[find(subject)].append(subject)
    by_class = defaultdict(list)
    for subjects in groups.values():
        by_class[subject_labels[subjects[0]]].append(tuple(subjects))
    assignment = {}
    randomizer = random.Random(seed)
    for label, name in LABELS.items():
        class_groups = sorted(by_class[label])
        if len(class_groups) < 3:
            raise ValueError(
                f"Class {label} ({name}) has {len(class_groups)} independent groups; "
                "at least 3 are required for coverage of every split"
            )
        randomizer.shuffle(class_groups)
        class_groups.sort(key=len, reverse=True)
        total = sum(map(len, class_groups))
        counts = [0, 0, 0]
        for index, subjects in enumerate(class_groups):
            empty = [split for split, count in enumerate(counts) if count == 0]
            candidates = empty if len(class_groups) - index == len(empty) else range(3)
            selected = min(
                candidates,
                key=lambda split: (
                    sum(
                        ((counts[i] + (len(subjects) if i == split else 0)) / total - ratios[i])
                        ** 2
                        for i in range(3)
                    ),
                    split,
                ),
            )
            counts[selected] += len(subjects)
            for subject in subjects:
                assignment[subject] = SPLITS[selected]

    canonical = sorted(tuple(row[field] for field in FIELDS) for row in rows)
    digest = hashlib.sha256(
        json.dumps(canonical, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    audit = {
        "manifest_sha256": digest,
        "seed": seed,
        "ratios": dict(zip(SPLITS, ratios)),
        "splits": {},
    }
    for split in SPLITS:
        subjects = {subject for subject, value in assignment.items() if value == split}
        split_rows = [row for row in rows if row["subject_id"] in subjects]
        split_groups = [group for group in groups.values() if group[0] in subjects]
        audit["splits"][split] = {
            "subjects": len(subjects),
            "images": len(split_rows),
            "groups": len(split_groups),
            "classes": {
                name: {
                    "subjects": sum(subject_labels[subject] == label for subject in subjects),
                    "images": sum(row["label"] == label for row in split_rows),
                    "groups": sum(subject_labels[group[0]] == label for group in split_groups),
                }
                for label, name in LABELS.items()
            },
        }
    return assignment, audit


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--audit", type=Path)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--ratios", type=float, nargs=3, default=(0.7, 0.15, 0.15))
    args = parser.parse_args(argv)
    audit_path = args.audit or args.output.with_suffix(args.output.suffix + ".audit.json")
    if len({args.manifest.resolve(), args.output.resolve(), audit_path.resolve()}) != 3:
        parser.error("Manifest, output, and audit paths must be distinct")
    try:
        rows = read_manifest(args.manifest)
        assignment, audit = split_manifest(rows, args.seed, args.ratios)
        with args.output.open("w", encoding="utf-8", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=(*FIELDS, "split"), lineterminator="\n")
            writer.writeheader()
            for row in sorted(rows, key=lambda item: tuple(item[field] for field in FIELDS)):
                writer.writerow({**row, "split": assignment[row["subject_id"]]})
        audit_path.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except (ValueError, OSError, csv.Error) as error:
        parser.exit(2, f"error: {error}\n")
    print(json.dumps(audit, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
