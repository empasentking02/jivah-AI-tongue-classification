import csv
import hashlib
import json
import subprocess
import sys

import pytest

from ml.split import FIELDS, LABELS, read_manifest, split_manifest


def make_rows(count=10):
    return [
        {
            "path": f"{label}-{index}.jpg",
            "subject_id": f"{label}-{index}",
            "camera": "0",
            "label": label,
            "label_name": name,
            "width": "20",
            "height": "20",
            "sha256": hashlib.sha256(f"{label}-{index}".encode()).hexdigest(),
        }
        for label, name in LABELS.items()
        for index in range(count)
    ]


def write_manifest(path, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def test_reproducible_balanced_and_disjoint():
    rows = make_rows(20)
    assignment, audit = split_manifest(rows, seed=21)
    other, other_audit = split_manifest(list(reversed(rows)), seed=21)
    assert assignment == other
    assert audit == other_audit
    assert set(assignment) == {row["subject_id"] for row in rows}
    for summary in audit["splits"].values():
        assert all(item["subjects"] > 0 for item in summary["classes"].values())
    assert [audit["splits"][name]["subjects"] for name in ("train", "validation", "test")] == [
        42,
        9,
        9,
    ]


def test_transitive_duplicate_bridge_and_variants():
    rows = make_rows()
    first, middle, last = rows[:3]
    rows.extend(
        [
            {**middle, "path": "bridge1", "sha256": first["sha256"]},
            {**last, "path": "bridge2", "sha256": middle["sha256"]},
            {**first, "path": "variant", "sha256": "f" * 64},
        ]
    )
    assignment, audit = split_manifest(rows)
    assert len({assignment[row["subject_id"]] for row in (first, middle, last)}) == 1
    assert sum(summary["images"] for summary in audit["splits"].values()) == len(rows)
    assert sum(summary["groups"] for summary in audit["splits"].values()) == 28
    for digest in {row["sha256"] for row in rows}:
        assert len({assignment[row["subject_id"]] for row in rows if row["sha256"] == digest}) == 1


@pytest.mark.parametrize("kind", ["subject", "duplicate"])
def test_conflicting_labels(kind):
    rows = make_rows()
    extra = dict(rows[10])
    extra["subject_id" if kind == "subject" else "sha256"] = rows[0][
        "subject_id" if kind == "subject" else "sha256"
    ]
    rows.append(extra)
    with pytest.raises(ValueError, match="Conflicting labels"):
        split_manifest(rows)


def test_sparse_classes_fail():
    with pytest.raises(ValueError, match="independent groups"):
        split_manifest(make_rows(2))


@pytest.mark.parametrize(
    "field,value",
    [
        ("subject_id", " "),
        ("subject_id", " x "),
        ("label", "3"),
        ("label_name", "Vata"),
        ("sha256", "not-a-hash"),
    ],
)
def test_invalid_manifest_fields(tmp_path, field, value):
    rows = make_rows()
    rows[0][field] = value
    source = tmp_path / "source.csv"
    write_manifest(source, rows)
    with pytest.raises(ValueError):
        read_manifest(source)
    with pytest.raises(ValueError):
        split_manifest(rows)


def test_cli(tmp_path):
    source, output = tmp_path / "source.csv", tmp_path / "split.csv"
    write_manifest(source, make_rows())
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "ml.split",
            str(source),
            "--output",
            str(output),
            "--seed",
            "7",
            "--ratios",
            "0.6",
            "0.2",
            "0.2",
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    audit = json.loads(result.stdout)
    assert audit == json.loads((tmp_path / "split.csv.audit.json").read_text(encoding="utf-8"))
    with output.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 30
    assert {row["split"] for row in rows} == {"train", "validation", "test"}


def test_cli_rejects_bad_ratios(tmp_path):
    source, output = tmp_path / "source.csv", tmp_path / "split.csv"
    write_manifest(source, make_rows())
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "ml.split",
            str(source),
            "--output",
            str(output),
            "--ratios",
            "1",
            "1",
            "1",
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode != 0
    assert not output.exists()
