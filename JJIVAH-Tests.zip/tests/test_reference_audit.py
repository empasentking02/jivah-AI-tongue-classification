import csv
import struct
import zipfile

import pytest

from scripts.reference_audit import build_report, read_central_directory, render_html


def test_provisional_report_counts_conflicts_and_masks(tmp_path):
    csv_path = tmp_path / "labels.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["Filename", "ID", "Camera", "Class"])
        writer.writeheader()
        writer.writerows(
            [
                {"Filename": "001_02_00-crop", "ID": "1", "Camera": "0", "Class": "0"},
                {"Filename": "001_02_01-crop", "ID": "1", "Camera": "1", "Class": "1"},
                {"Filename": "missing", "ID": "2", "Camera": "0", "Class": "2"},
            ]
        )
    archive_path = tmp_path / "sample.zip"
    with zipfile.ZipFile(archive_path, "w") as archive:
        archive.writestr("Crop_images/00/001_02_00-crop.JPG", b"image")
        archive.writestr("Crop_images/00/unlabeled.JPG", b"image")
        archive.writestr("ROI_images/00/mask/001_02_00-crop.png", b"mask")
    content = archive_path.read_bytes()
    end_pos = content.rfind(b"PK\x05\x06")
    footer = struct.unpack_from("<4s4H2LH", content, end_pos)
    central_path = tmp_path / "central.bin"
    central_path.write_bytes(content[footer[6] : footer[6] + footer[5]])
    report = build_report(csv_path, central_path)
    assert report["label_summary"]["rows"] == 3
    assert report["label_summary"]["candidate_ids"] == 2
    assert report["label_summary"]["conflicting_candidate_ids"] == 1
    assert report["archive_index"]["crop_photographs"] == 2
    assert report["archive_index"]["roi_masks"] == 1
    assert report["archive_index"]["unlabeled_crop_stems"] == 1
    assert report["archive_index"]["missing_labeled_crop_stems"] == 2
    assert report["images_decoded"] is False
    assert report["archive_checksum_verified"] is False
    assert "not a disease diagnosis" in render_html(report).lower()


def test_rejects_truncated_or_invalid_central_directory(tmp_path):
    path = tmp_path / "central.bin"
    path.write_bytes(b"PK\x01\x02" + b"\0" * 10)
    with pytest.raises(ValueError, match="Truncated"):
        read_central_directory(path)
