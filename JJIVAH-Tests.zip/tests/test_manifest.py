import csv
import hashlib
import json
import subprocess
import sys

import pytest
from PIL import Image

from ml.manifest import COLUMNS, audit


@pytest.fixture
def dataset(tmp_path):
    root = tmp_path / "raw"
    root.mkdir()
    labels = tmp_path / "labels.csv"

    def write(rows):
        with labels.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.writer(stream)
            writer.writerow(["Filename", "ID", "Camera", "Class"])
            writer.writerows(rows)

    def image(name, color):
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        Image.new("RGB", (4, 3), color).save(path)
        return path

    return root, labels, write, image


def test_valid_deterministic_and_roi_excluded(dataset):
    root, labels, write, image = dataset
    path = image("Crop_images/00/001_02_00-crop.JPG", "red")
    image("ROI_images/00/mask/001_02_00-crop.png", "white")
    write([["001_02_00-crop", "1", "0", "2"]])
    records, report = audit(root, labels)
    assert (records, report) == audit(root, labels)
    assert list(records[0]) == list(COLUMNS)
    assert records[0] == dict(
        zip(
            COLUMNS,
            [
                "Crop_images/00/001_02_00-crop.JPG",
                "1",
                "0",
                "2",
                "Kapha",
                4,
                3,
                hashlib.sha256(path.read_bytes()).hexdigest(),
            ],
        )
    )
    assert report["excluded_count"] == 1
    assert "unverified" in report["subject_id_notice"]
    assert report["training_ready"] is False


def test_quarantine_missing_invalid_duplicate_and_unmatched(dataset):
    root, labels, write, image = dataset
    image("dup.png", "red")
    image("extra.png", "green")
    (root / "bad.jpg").write_bytes(b"not an image")
    write(
        [
            ["dup", "1", "0", "0"],
            ["dup", "1", "0", "1"],
            ["missing", "2", "1", "2"],
            ["bad", "3", "0", "1"],
            ["unsafe/name", "4", "0", "0"],
        ]
    )
    records, report = audit(root, labels)
    assert records == []
    assert {item["reason"] for item in report["quarantine"]} == {
        "duplicate_csv_mapping",
        "missing_image",
        "invalid_image",
        "invalid_csv_row",
        "unmatched_image",
        "conflicting_candidate_id_labels",
    }


def test_duplicate_bytes_never_accepted(dataset):
    root, labels, write, image = dataset
    image("first.png", "red")
    image("second.png", "red")
    write([["first", "1", "0", "0"], ["second", "2", "1", "1"]])
    records, report = audit(root, labels)
    assert records == []
    assert report["quarantine"][0]["reason"] == "duplicate_image_bytes"


def test_unmatched_duplicate_blocks_matched_image(dataset):
    root, labels, write, image = dataset
    image("first.png", "red")
    image("unknown.png", "red")
    write([["first", "1", "0", "0"]])
    records, report = audit(root, labels)
    assert records == []
    assert {item["reason"] for item in report["quarantine"]} == {
        "duplicate_image_bytes",
        "unmatched_image",
    }


def test_camera_directory_does_not_prove_duplicate_identity(dataset):
    root, labels, write, image = dataset
    image("Crop_images/00/same.JPG", "red")
    image("Crop_images/01/same.JPG", "blue")
    write([["same", "1", "1", "0"]])
    records, report = audit(root, labels)
    assert records == []
    assert report["quarantine"][0]["reason"] == "ambiguous_image_mapping"


def test_conflicting_candidate_id_quarantines_all_views(dataset):
    root, labels, write, image = dataset
    image("one.png", "red")
    image("two.png", "blue")
    write([["one", "01", "0", "0"], ["two", "1", "1", "1"]])
    records, report = audit(root, labels)
    assert records == []
    assert [item["reason"] for item in report["quarantine"]].count(
        "conflicting_candidate_id_image"
    ) == 2
    assert any(item["reason"] == "conflicting_candidate_id_labels" for item in report["quarantine"])


def test_cli_fails_closed_on_issues(dataset, tmp_path):
    root, labels, write, _ = dataset
    write([["missing", "1", "0", "0"]])
    manifest = tmp_path / "manifest.csv"
    report = tmp_path / "report.json"
    result = subprocess.run(
        [sys.executable, "-m", "ml.manifest", str(root), str(labels), str(manifest), str(report)],
        check=False,
    )
    assert result.returncode == 1
    assert json.loads(report.read_text(encoding="utf-8"))["training_ready"] is False
    assert manifest.read_text(encoding="utf-8").strip() == ",".join(COLUMNS)
