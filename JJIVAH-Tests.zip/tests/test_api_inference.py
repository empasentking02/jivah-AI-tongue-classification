import hashlib
import io
import json
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pytest
from fastapi.testclient import TestClient
from PIL import Image

from services.api.main import (
    MAX_BODY,
    PREPROCESSING,
    Metadata,
    ServingApproval,
    app,
    decode_image,
    infer,
)


@pytest.fixture(scope="module")
def artifact_files(tmp_path_factory):
    import tensorflow as tf

    root = tmp_path_factory.mktemp("synthetic_api_model")
    inputs = tf.keras.Input((224, 224, 3), dtype="float32")
    output = tf.keras.layers.GlobalAveragePooling2D()(inputs)
    output = tf.keras.layers.Rescaling(1 / 255)(output)
    output = tf.keras.layers.Dense(3, kernel_initializer="identity", bias_initializer="zeros")(
        output
    )
    output = tf.keras.layers.Softmax()(output)
    model_path = root / "synthetic.keras"
    tf.keras.Model(inputs, output).save(model_path)
    model_hash = hashlib.sha256(model_path.read_bytes()).hexdigest()
    evidence = {
        "research_only": True,
        "split": "test",
        "model_sha256": model_hash,
        "split_sha256": "a" * 64,
        "labels": {"0": "Pitta", "1": "Vata", "2": "Kapha"},
        "count": 1,
        "subject_count": 1,
        "macro_f1": 0.5,
        "balanced_accuracy": 0.5,
    }
    evidence_path = root / "synthetic_evaluation.json"
    evidence_path.write_text(json.dumps(evidence), encoding="utf-8")
    metadata = {
        "model_sha256": model_hash,
        "split_sha256": "a" * 64,
        "approval_sha256": "b" * 64,
        "preprocessing": PREPROCESSING,
        "labels": {"0": "Pitta", "1": "Vata", "2": "Kapha"},
        "input": {
            "shape": [None, 224, 224, 3],
            "dtype": "float32",
            "range": [0, 255],
            "color": "RGB",
        },
        "config": {},
    }
    metadata_path = root / "synthetic_metadata.json"
    metadata_path.write_text(json.dumps(metadata), encoding="utf-8")
    approval = {
        "approved": True,
        "model_version": "synthetic-test-only",
        "model_sha256": model_hash,
        "split_sha256": "a" * 64,
        "metadata_sha256": hashlib.sha256(metadata_path.read_bytes()).hexdigest(),
        "evaluation_sha256": hashlib.sha256(evidence_path.read_bytes()).hexdigest(),
        "reviewer": "test fixture",
        "evidence": "synthetic only; not approved for deployment",
    }
    approval_path = root / "synthetic_serving_approval.json"
    approval_path.write_text(json.dumps(approval), encoding="utf-8")
    return model_path, metadata_path, evidence_path, approval_path, metadata, approval


@pytest.fixture
def configured(monkeypatch, artifact_files):
    model, metadata, evidence, approval, _, _ = artifact_files
    monkeypatch.delenv("JEEVAH_EXPERIMENTAL", raising=False)
    monkeypatch.setenv("JEEVAH_MODEL_PATH", str(model))
    monkeypatch.setenv("JEEVAH_METADATA_PATH", str(metadata))
    monkeypatch.setenv("JEEVAH_EVALUATION_PATH", str(evidence))
    monkeypatch.setenv("JEEVAH_SERVING_APPROVAL_PATH", str(approval))


@pytest.fixture
def experimental(configured, artifact_files, tmp_path, monkeypatch):
    metadata = {
        **artifact_files[4],
        "research_only": True,
        "experimental": True,
        "approval_sha256": None,
    }
    path = tmp_path / "experimental.json"
    path.write_text(json.dumps(metadata), encoding="utf-8")
    monkeypatch.setenv("JEEVAH_METADATA_PATH", str(path))
    monkeypatch.delenv("JEEVAH_SERVING_APPROVAL_PATH", raising=False)
    monkeypatch.setenv("JEEVAH_EXPERIMENTAL", "1")
    return metadata, path


def png_bytes():
    data = io.BytesIO()
    Image.new("RGB", (8, 8), (100, 150, 200)).save(data, format="PNG")
    return data.getvalue()


def test_approved_fixture_runs_real_inference(configured):
    with TestClient(app) as client:
        assert client.get("/api/health").json()["ready"] is True
        response = client.post("/api/predict", files={"image": ("x.png", png_bytes(), "image/png")})
        assert response.status_code == 200
        result = response.json()
        assert result["label"] == "Kapha"
        assert [entry["label"] for entry in result["scores"]] == ["Kapha", "Vata", "Pitta"]
        expected = np.exp(np.array([200, 150, 100]) / 255)
        np.testing.assert_allclose(
            [entry["score"] for entry in result["scores"]], expected / expected.sum(), rtol=1e-6
        )
        assert result["model_version"] == "synthetic-test-only"
        assert "not a medical diagnosis" in result["warnings"][0]


def test_experimental_model_runs_with_visible_warning(experimental):
    metadata, _ = experimental
    with TestClient(app) as client:
        assert client.get("/api/health").json()["ready"] is True
        info = client.get("/api/model").json()
        result = client.post("/api/predict", files={"image": ("x.png", png_bytes(), "image/png")})
        assert result.status_code == 200
        prediction = result.json()
        assert prediction["model_version"] == f"experimental-{metadata['model_sha256'][:12]}"
        assert info["model_version"] == prediction["model_version"]
        for response in (info, prediction):
            assert any(
                "Unreviewed experimental model" in warning for warning in response["warnings"]
            )
            assert any("not a medical diagnosis" in warning for warning in response["warnings"])


def test_experimental_model_discloses_low_test_performance(
    experimental, artifact_files, tmp_path, monkeypatch
):
    report = json.loads(artifact_files[2].read_bytes())
    report.update(macro_f1=0.27, per_class={"Vata": {"recall": 0.0, "support": 5}})
    report_path = tmp_path / "low-performance.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    monkeypatch.setenv("JEEVAH_EVALUATION_PATH", str(report_path))
    with TestClient(app) as client:
        response = client.post("/api/predict", files={"image": ("x.png", png_bytes(), "image/png")})
    assert response.status_code == 200
    assert any("No Vata test images" in item for item in response.json()["warnings"])


@pytest.mark.parametrize("setting", [None, "0", "true", "01"])
def test_experimental_requires_exact_opt_in(experimental, monkeypatch, setting):
    if setting is None:
        monkeypatch.delenv("JEEVAH_EXPERIMENTAL")
    else:
        monkeypatch.setenv("JEEVAH_EXPERIMENTAL", setting)
    with TestClient(app) as client:
        assert client.get("/api/health").json()["ready"] is False
        assert client.post("/api/predict").status_code == 503


@pytest.mark.parametrize(
    "field,value",
    [
        ("research_only", False),
        ("experimental", False),
        ("model_sha256", "0" * 64),
        ("split_sha256", "0" * 64),
        ("labels", {"0": "Vata", "1": "Pitta", "2": "Kapha"}),
        ("preprocessing", "unknown"),
        ("input", {}),
    ],
)
def test_experimental_invalid_metadata_rejected(experimental, field, value):
    metadata, path = experimental
    path.write_text(json.dumps({**metadata, field: value}), encoding="utf-8")
    with TestClient(app) as client:
        assert client.get("/api/health").json()["ready"] is False


@pytest.mark.parametrize(
    "field,value",
    [
        ("research_only", False),
        ("split", "validation"),
        ("model_sha256", "0" * 64),
        ("split_sha256", "0" * 64),
        ("labels", {}),
        ("subject_count", 2),
    ],
)
def test_experimental_invalid_evaluation_rejected(
    experimental, artifact_files, tmp_path, monkeypatch, field, value
):
    report = json.loads(artifact_files[2].read_bytes())
    report[field] = value
    path = tmp_path / "evaluation.json"
    path.write_text(json.dumps(report), encoding="utf-8")
    monkeypatch.setenv("JEEVAH_EVALUATION_PATH", str(path))
    with TestClient(app) as client:
        assert client.get("/api/health").json()["ready"] is False


def test_opt_in_does_not_bypass_approval_for_standard_metadata(configured, monkeypatch):
    monkeypatch.setenv("JEEVAH_EXPERIMENTAL", "1")
    monkeypatch.delenv("JEEVAH_SERVING_APPROVAL_PATH")
    with TestClient(app) as client:
        assert client.get("/api/health").json()["ready"] is False


@pytest.mark.parametrize(
    "field,value",
    [
        ("model_sha256", "0" * 64),
        ("labels", {"0": "Vata", "1": "Pitta", "2": "Kapha"}),
        ("preprocessing", "unknown"),
    ],
)
def test_invalid_metadata_never_loads(
    configured, artifact_files, tmp_path, monkeypatch, field, value
):
    metadata = {**artifact_files[4], field: value}
    path = tmp_path / "metadata.json"
    path.write_text(json.dumps(metadata), encoding="utf-8")
    approval = {
        **artifact_files[5],
        "metadata_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }
    approval_path = tmp_path / "approval.json"
    approval_path.write_text(json.dumps(approval), encoding="utf-8")
    monkeypatch.setenv("JEEVAH_METADATA_PATH", str(path))
    monkeypatch.setenv("JEEVAH_SERVING_APPROVAL_PATH", str(approval_path))
    with TestClient(app) as client:
        assert client.get("/api/health").json()["ready"] is False
        assert client.post("/api/predict").status_code == 503


@pytest.mark.parametrize(
    "field,value",
    [("approved", False), ("approved", 1), ("evaluation_sha256", "0" * 64), ("reviewer", " ")],
)
def test_invalid_serving_approval(configured, artifact_files, tmp_path, monkeypatch, field, value):
    approval = {**artifact_files[5], field: value}
    path = tmp_path / "approval.json"
    path.write_text(json.dumps(approval), encoding="utf-8")
    monkeypatch.setenv("JEEVAH_SERVING_APPROVAL_PATH", str(path))
    with TestClient(app) as client:
        assert client.get("/api/health").json()["ready"] is False


def test_training_serving_resize_parity(tmp_path):
    import tensorflow as tf

    from ml.train import make_dataset

    image = Image.new("RGB", (3, 2))
    image.putdata([(0, 4, 200), (255, 3, 0), (10, 90, 80), (100, 200, 1), (55, 3, 9), (22, 70, 99)])
    path = tmp_path / "image.png"
    image.save(path)
    rows = [{"split": "test", "absolute_path": str(path), "label": "0"}]
    batch, _ = next(iter(make_dataset(rows, "test", {"batch_size": 1})))
    content_type = "multipart/form-data; boundary=jeevah"
    body = (
        b'--jeevah\r\nContent-Disposition: form-data; name="image"; filename="x.png"\r\n'
        b"Content-Type: image/png\r\n\r\n" + path.read_bytes() + b"\r\n--jeevah--\r\n"
    )
    actual = decode_image(content_type, body)
    np.testing.assert_allclose(actual, batch.numpy(), rtol=0, atol=0)
    assert tf.as_dtype(actual.dtype) == tf.float32


@pytest.mark.parametrize("scores", [[1.1, -0.1, 0.0], [0.1, 0.2, 0.3], [float("nan"), 0.0, 1.0]])
def test_invalid_model_scores_rejected(artifact_files, scores):
    metadata = Metadata.model_validate(artifact_files[4])
    approval = ServingApproval.model_validate(artifact_files[5])

    def model(inputs, training=False):
        return np.array([scores])

    with pytest.raises(ValueError, match="Invalid model output"):
        infer(model, metadata, approval, np.zeros((1, 224, 224, 3), dtype=np.float32))


def test_bad_uploads_and_oversize(configured):
    with TestClient(app) as client:
        for files in (
            {"image": ("x.png", b"corrupt", "image/png")},
            {"image": ("x.jpg", png_bytes(), "image/jpeg")},
            {"image": ("x.gif", b"GIF89a", "image/gif")},
            {"wrong": ("x.png", png_bytes(), "image/png")},
        ):
            assert client.post("/api/predict", files=files).status_code in (400, 415)
        assert client.post("/api/predict", content=b"x" * (MAX_BODY + 1)).status_code == 413


def test_image_size_boundary(configured, monkeypatch):
    data = png_bytes()
    monkeypatch.setattr("services.api.main.MAX_IMAGE_BYTES", len(data))
    with TestClient(app) as client:
        assert (
            client.post("/api/predict", files={"image": ("x.png", data, "image/png")}).status_code
            == 200
        )
        assert (
            client.post(
                "/api/predict", files={"image": ("x.png", data + b"x", "image/png")}
            ).status_code
            == 413
        )


@pytest.mark.parametrize(
    "field,value",
    [
        ("split", "validation"),
        ("model_sha256", "0" * 64),
        ("split_sha256", "0" * 64),
        ("subject_count", 0),
        ("research_only", False),
    ],
)
def test_invalid_evaluation_report(configured, artifact_files, tmp_path, monkeypatch, field, value):
    report = json.loads(artifact_files[2].read_bytes())
    report[field] = value
    report_path = tmp_path / "report.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    approval = {
        **artifact_files[5],
        "evaluation_sha256": hashlib.sha256(report_path.read_bytes()).hexdigest(),
    }
    approval_path = tmp_path / "approval.json"
    approval_path.write_text(json.dumps(approval), encoding="utf-8")
    monkeypatch.setenv("JEEVAH_EVALUATION_PATH", str(report_path))
    monkeypatch.setenv("JEEVAH_SERVING_APPROVAL_PATH", str(approval_path))
    with TestClient(app) as client:
        assert client.get("/api/health").json()["ready"] is False


def test_pixel_limit_and_streaming_body_limit(configured, monkeypatch):
    monkeypatch.setattr("services.api.main.MAX_PIXELS", 4)
    with TestClient(app) as client:
        response = client.post("/api/predict", files={"image": ("x.png", png_bytes(), "image/png")})
        assert response.status_code == 400
        chunks = iter([b"x" * (MAX_BODY // 2), b"x" * (MAX_BODY // 2 + 1)])
        assert client.post("/api/predict", content=chunks).status_code == 413


def test_concurrent_predictions(configured):
    with TestClient(app) as client:

        def predict(_):
            return client.post("/api/predict", files={"image": ("x.png", png_bytes(), "image/png")})

        with ThreadPoolExecutor(max_workers=3) as pool:
            responses = list(pool.map(predict, range(3)))
        assert all(response.status_code == 200 for response in responses)
