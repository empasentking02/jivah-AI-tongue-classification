import csv
import json

import numpy as np
import pytest
from PIL import Image

from ml.evaluate import evaluate
from ml.split import FIELDS, LABELS, SPLITS
from ml.train import build_model, class_weights, load_approved_split, sha256


@pytest.fixture
def split_data(tmp_path):
    rows = []
    for split_index, split in enumerate(SPLITS):
        for label, name in LABELS.items():
            filename = f"{split}-{label}.png"
            image = tmp_path / filename
            Image.new("RGB", (2, 2), (split_index * 70, int(label) * 70, 12)).save(image)
            rows.append(
                {
                    "path": filename,
                    "subject_id": f"{split}-{label}",
                    "camera": "0",
                    "label": label,
                    "label_name": name,
                    "width": "2",
                    "height": "2",
                    "sha256": sha256(image),
                    "split": split,
                }
            )
    path = tmp_path / "split.csv"
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=[*FIELDS, "split"])
        writer.writeheader()
        writer.writerows(rows)
    approval = tmp_path / "approval.json"
    approval.write_text(
        json.dumps(
            {
                "approved": True,
                "split_sha256": sha256(path),
                "reviewer": "test",
                "evidence": "synthetic fixture only",
            }
        ),
        encoding="utf-8",
    )
    return path, tmp_path, approval, rows


def test_approval_and_content_binding(split_data):
    path, root, approval, rows = split_data
    assert len(load_approved_split(path, root, approval)) == 9
    (root / rows[0]["path"]).write_bytes(b"changed")
    with pytest.raises(ValueError, match="content"):
        load_approved_split(path, root, approval)
    approval.write_text("{}", encoding="utf-8")
    with pytest.raises(ValueError, match="approval"):
        load_approved_split(path, root, approval)


def test_subject_leakage_rejected(split_data):
    path, root, approval, rows = split_data
    rows[3]["subject_id"] = rows[0]["subject_id"]
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=[*FIELDS, "split"])
        writer.writeheader()
        writer.writerows(rows)
    approval.write_text(
        json.dumps(
            {
                "approved": True,
                "split_sha256": sha256(path),
                "reviewer": "test",
                "evidence": "synthetic",
            }
        ),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="crosses splits"):
        load_approved_split(path, root, approval)


def test_experimental_split_is_explicit_and_does_not_forge_approval(split_data):
    path, root, approval, rows = split_data
    with pytest.raises(ValueError, match="approval"):
        load_approved_split(path, root)
    with pytest.raises(ValueError, match="must not claim"):
        load_approved_split(path, root, approval, experimental=True)
    assert len(load_approved_split(path, root, experimental=True)) == 9
    (root / rows[0]["path"]).write_bytes(b"changed")
    with pytest.raises(ValueError, match="content"):
        load_approved_split(path, root, experimental=True)


def test_training_weights_only(split_data):
    rows = split_data[3] + [dict(split_data[3][3]) for _ in range(5)]
    assert class_weights(rows) == {0: 1, 1: 1, 2: 1}


def test_metrics_and_invalid_predictions(split_data):
    class Dummy:
        def predict(self, dataset, verbose=0):
            return np.eye(3)

    report = evaluate(Dummy(), None, split_data[3], "test")
    assert report["macro_f1"] == 1 and report["confusion_matrix"] == np.eye(3).tolist()

    class Invalid:
        def predict(self, dataset, verbose=0):
            return np.full((3, 3), np.nan)

    with pytest.raises(ValueError, match="scores"):
        evaluate(Invalid(), None, split_data[3], "test")


def test_densenet_preprocessing_and_roundtrip(tmp_path):
    import tensorflow as tf

    model = build_model(weights=None)
    pixels = tf.constant(np.full((1, 224, 224, 3), 120, dtype=np.float32))
    preprocessing = tf.keras.Model(model.input, model.layers[2].output)
    expected = tf.keras.applications.densenet.preprocess_input(pixels)
    np.testing.assert_allclose(preprocessing(pixels).numpy(), expected.numpy(), atol=1e-6)
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy")
    loss = model.train_on_batch(pixels, np.array([0]))
    assert np.isfinite(loss)
    scores = model(pixels, training=False).numpy()
    path = tmp_path / "synthetic.keras"
    model.save(path)
    reloaded = tf.keras.models.load_model(path, compile=False)
    np.testing.assert_allclose(scores, reloaded(pixels, training=False).numpy(), atol=1e-6)
    assert scores.shape == (1, 3) and np.isfinite(scores).all()
