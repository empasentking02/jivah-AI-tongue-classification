from PIL import Image

from ml.near_duplicates import difference_hash, screen


def test_difference_hash_is_deterministic_for_uniform_image():
    image = Image.new("RGB", (20, 20), "red")
    assert difference_hash(image) == 0


def test_screen_excludes_entire_candidate_groups_for_similar_cross_id_images():
    rows = [
        {"subject_id": "1", "path": "one.jpg"},
        {"subject_id": "1", "path": "one-other.jpg"},
        {"subject_id": "2", "path": "two.jpg"},
        {"subject_id": "3", "path": "three.jpg"},
    ]
    retained, matches, excluded = screen(rows, [0, 255, 1, (1 << 64) - 1], 1)
    assert excluded == {"1", "2"}
    assert [row["subject_id"] for row in retained] == ["3"]
    assert len(matches) == 1
