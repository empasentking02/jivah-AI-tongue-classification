import hashlib
import stat
import tempfile
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from scripts.dataset import (
    acquisition_lock,
    download_archive,
    inspect_archive,
    validate_member,
    verify_archive,
)


class ArchiveSafetyTests(unittest.TestCase):
    def test_accepts_normal_image(self):
        self.assertEqual(
            str(validate_member(zipfile.ZipInfo("dataset/crop/image.jpg"))),
            "dataset/crop/image.jpg",
        )

    def test_rejects_unsafe_paths(self):
        for name in (
            "../escape",
            "/absolute",
            "C:/drive",
            "x/../../escape",
            "x\\escape",
            "file:stream",
            "folder./file",
            "folder /file",
            ".",
            "x\x00hidden",
        ):
            with self.subTest(name=name), self.assertRaises(ValueError):
                validate_member(zipfile.ZipInfo(name))

    def test_rejects_symlink(self):
        member = zipfile.ZipInfo("link")
        member.external_attr = (stat.S_IFLNK | 0o777) << 16
        with self.assertRaises(ValueError):
            validate_member(member)

    def test_rejects_case_collisions(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "sample.zip"
            with zipfile.ZipFile(path, "w") as bundle:
                bundle.writestr("Image.jpg", b"first")
                bundle.writestr("image.jpg", b"second")
            with self.assertRaises(ValueError):
                inspect_archive(path)

    def test_accepts_matching_size_and_checksum(self):
        content = b"test-only archive bytes"
        checksum = hashlib.md5(content, usedforsecurity=False).hexdigest()
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "archive.zip"
            path.write_bytes(content)
            with (
                patch("scripts.dataset.EXPECTED_BYTES", len(content)),
                patch("scripts.dataset.EXPECTED_MD5", checksum),
            ):
                self.assertEqual(verify_archive(path), checksum)

    def test_rejects_wrong_size(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "archive.zip"
            path.write_bytes(b"partial")
            with self.assertRaisesRegex(ValueError, "size"):
                verify_archive(path)

    def test_rejects_wrong_checksum(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "archive.zip"
            path.write_bytes(b"corrupt")
            with (
                patch("scripts.dataset.EXPECTED_BYTES", 7),
                self.assertRaisesRegex(ValueError, "MD5"),
            ):
                verify_archive(path)

    def test_retries_from_latest_partial_after_connection_failures(self):
        with tempfile.TemporaryDirectory() as temporary:
            partial = Path(temporary) / "archive.part"
            calls = []

            def transfer(arguments, check):
                calls.append(arguments)
                with partial.open("ab") as output:
                    output.write(b"ab")
                return SimpleNamespace(returncode=0 if len(calls) == 3 else 18)

            with (
                patch("scripts.dataset.PARTIAL", partial),
                patch("scripts.dataset.EXPECTED_BYTES", 6),
                patch("scripts.dataset.subprocess.run", side_effect=transfer),
                patch("scripts.dataset.time.sleep"),
            ):
                download_archive("curl")
            self.assertEqual(partial.read_bytes(), b"ababab")
            self.assertEqual(len(calls), 3)
            self.assertTrue(all("--continue-at" in call for call in calls))

    def test_retries_stop_after_repeated_no_progress(self):
        with tempfile.TemporaryDirectory() as temporary:
            partial = Path(temporary) / "archive.part"
            with (
                patch("scripts.dataset.PARTIAL", partial),
                patch("scripts.dataset.EXPECTED_BYTES", 6),
                patch("scripts.dataset.MAX_STALLED_ATTEMPTS", 2),
                patch(
                    "scripts.dataset.subprocess.run", return_value=SimpleNamespace(returncode=56)
                ),
                patch("scripts.dataset.time.sleep"),
                self.assertRaisesRegex(RuntimeError, "stalled"),
            ):
                download_archive("curl")

    def test_acquisition_lock_rejects_second_downloader(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            with (
                acquisition_lock(directory),
                self.assertRaisesRegex(RuntimeError, "already running"),
                acquisition_lock(directory),
            ):
                pass
            with acquisition_lock(directory):
                pass


if __name__ == "__main__":
    unittest.main()
