from fastapi.testclient import TestClient

from services.api.main import NOTICE, UNAVAILABLE, app


def test_health_is_live_but_not_ready():
    with TestClient(app) as client:
        response = client.get("/api/health")
        assert response.status_code == 200
        assert response.json() == {"status": "ok", "ready": False}
        for path in ("/api/ready", "/api/model"):
            response = client.get(path)
            assert response.status_code == 503
            assert response.json() == {"detail": UNAVAILABLE}


def test_prediction_rejects_without_persisting_upload(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    with TestClient(app) as client:
        for request in (
            {},
            {"files": {"image": ("tongue.png", b"not an image", "image/png")}},
            {"content": b"x" * 2_000_000, "headers": {"content-type": "image/jpeg"}},
        ):
            response = client.post("/api/predict", **request)
            assert response.status_code == 503
            assert response.json() == {"detail": UNAVAILABLE}
    assert list(tmp_path.iterdir()) == []


def test_openapi_documents_multipart_image_and_research_boundary():
    with TestClient(app) as client:
        schema = client.get("/openapi.json").json()
    assert NOTICE in schema["info"]["description"]
    body = schema["paths"]["/api/predict"]["post"]["requestBody"]
    image = body["content"]["multipart/form-data"]["schema"]
    assert body["required"] is True
    assert image["required"] == ["image"]
    assert image["properties"]["image"]["format"] == "binary"
    prediction = schema["components"]["schemas"]["Prediction"]
    assert {"label", "scores"} <= set(prediction["required"])
    assert prediction["properties"]["label"]["enum"] == ["Pitta", "Vata", "Kapha"]
    score = schema["components"]["schemas"]["CategoryScore"]
    assert set(score["required"]) == {"label", "score"}
    assert score["properties"]["score"]["type"] == "number"
