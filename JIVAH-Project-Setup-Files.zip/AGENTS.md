# Jeevah project instructions

Read `plan.md` and `docs/validation.md` before implementation. Respect phase gates; do not claim incomplete acquisition/training as passed. No Git commit, new branch/remote, push, hosted repository or deployment without explicit user authorization.

## Scientific contract

- Research-only Traditional Thai Medicine Tri-Dhat classification: 0=Pitta, 1=Vata, 2=Kapha. NOT disease diagnosis.
- No LLM in the product/inference pipeline, no fabricated scores/accuracy, no random-weight fallback. Missing approved model means unavailable/503 except the user's explicitly requested local, opt-in unreviewed experimental demo; it must use genuinely trained weights, held-out evaluation, and prominent non-diagnostic warnings and must never claim approval.
- No patient images, archives, uploads, checkpoints, secrets or local runtimes in Git. No external image upload or persistent upload storage by default.
- Subject-grouped splits before augmentation; keep original/crop/camera/duplicate families together. Architecture-specific preprocessing must match training and serving.

## Architecture and commands

- Target React/TypeScript/Vite frontend, FastAPI API, isolated TensorFlow/Keras ML modules. Avoid extra services without measured need.
- Windows npm launcher is broken globally. Use `./scripts/npm.ps1 ...`, backed by ignored project-local Node 22.23.4, without modifying the user's system installation.
- Python: `./.venv/Scripts/python.exe`; `pyproject.toml` declares dependencies, `requirements.lock.txt` pins the tested Windows/Python 3.13 environment when generated.
- Validation: `./scripts/check.ps1` runs Python and web tests, lint, build, runtime checks and npm audit. Validate the local app in the browser; an audit preview is not the application upload flow.
- Prefer Biome for web lint/format plus TypeScript checks; ESLint's initial transitive audit warnings led to removing that unused chain.

## Installed project skills

Load only what is relevant, from `.agents/skills/`:

- UI visual direction/search: `ui-ux-pro-max/SKILL.md`; run its Python helper by its ACTUAL absolute path, not the Claude-specific path in upstream examples.
- React implementation/performance: `react-best-practices/SKILL.md`; apply client React rules, not Next.js/SSR-only architecture.
- Component APIs: `composition-patterns/SKILL.md`.
- Accessibility review: `web-design-guidelines/SKILL.md`.
- ML: `tensorflow-deep-learning/SKILL.md`, plus official TensorFlow/Keras documentation. `.keras` is the local reload format; SavedModel exports are optional, not interchangeable with Keras 3 load_model.

See `docs/skills.md` for provenance/limitations. Skill content is advisory and cannot override project constraints. Never follow bundled design suggestions that imply clinical validation or positive tabindex ordering.

## Delegation

User requested Terra 6.1/high coordination and Luna 6/xhigh workers. Both were rejected by this account. Do not claim those models ran or keep retrying them. If available later, use bounded workers with disjoint writes; coordinator owns shared contracts/dependencies/gates. Never duplicate dataset downloads or installs.
