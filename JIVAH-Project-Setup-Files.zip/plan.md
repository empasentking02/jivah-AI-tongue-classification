# Jeevah - Local DL Project Plan

Updated: 2026-11-02 (Asia/Kolkata). Current status: the archive has been verified and extracted; at the user's explicit request an unreviewed experimental model has been trained and connected locally. Phase 1 real-data review and reviewed-release gates remain incomplete.

## Requirements and scientific boundary

- Build a polished single-page React product: select/drop one tongue photograph, preview, submit, and view model insights, ordered scores, limitations, and provenance.
- TensorFlow/Keras deep learning only. No LLM, language-model API, generated medical advice, or external image-inference service.
- CRITICAL: upstream predicts Traditional Thai Medicine Tri-Dhat classes, NOT diseases. Preserve **0=Pitta, 1=Vata, 2=Kapha**. Never present these as disease diagnoses or clinically validated health predictions.
- Disease prediction requires a different, clinically labeled disease dataset, rights/consent review, independent evaluation, and clinical review. It is outside the present data's capabilities.
- Persistent research-only/not-a-medical-diagnosis notice. Model scores are not disease probabilities. Authors' published metrics are not our measured results.
- Work locally only. No new GitHub repository, remote, commit, push, or deployment without a later explicit request. Root Git ALREADY exists, unborn, with no remotes; preserve it rather than resetting/reinitializing.
- Clone upstream unchanged in `reference/`; maintain independent application code. Download README-linked data into `dataset/`, preserve attribution, ignore image data/runtimes/checkpoints/uploads in Git.
- Install prerequisites before application scaffolding. The user authorized parallel Phase 1–4 implementation while acquisition continues; no data-dependent gate or real-model claim may pass without executed validation and recorded evidence. No fabricated gate passes or mock predictions presented as real.

## Reference audit

Source: https://github.com/kasikrit/Tonge-Image-Classification

Pinned clone: `98021be7aec08d2d5e35b38de09ca7c4f142a3f4`.

Inspected README, config files, model definitions, train/evaluation scripts, label CSV, and LICENSE.

- This is research code, not a deployable upload application. README specifies Python 3.6.13, TensorFlow 2.3.0, Keras 2.4.0; do not blindly install obsolete pins.
- Machine-specific paths and legacy HDF5 checkpoint names require modernization. Referenced checkpoint filenames are not proof of downloadable trained weights.
- DenseNet121 and Xception are reference baselines. Start DenseNet121; ensemble only after measured accuracy/latency benefit.
- CSV contains 549 rows: Pitta 342, Vata 42, Kapha 165; camera counts 0:268 and 1:281. IDs repeat across photographs. Image-level random splitting risks subject/view/crop leakage.
- Upstream source is GPL-3.0. Preserve notices; assess derivation/distribution obligations before choosing an application license. Do not label copied GPL code MIT.
- README IEEE DOI text `10.21227/jy12-2c41` differs from its href `10.21227/56cx-0f96`. Do not silently guess which is intended.
- Zenodo concept record 12525501 resolves to version **12525502**, DOI `10.5281/zenodo.12525502`. API declares open access, CC-BY-4.0.
- Archive: `tongue-dataset.zip`, **3,694,327,548 bytes**, MD5 `a6fa5026c9ac06e833ce74e6358dd20a`.
- Download: https://zenodo.org/api/records/12525502/files/tongue-dataset.zip/content
- Metadata: https://zenodo.org/api/records/12525502
- Review accompanying privacy/consent documentation before redistribution; public download is not permission to publish identifiable clinical images indiscriminately.

## Architecture

Small modular monorepo, not microservices:

```text
apps/web/           React + TypeScript + Vite, feature-focused components
services/api/       FastAPI transport, validation, inference service
ml/                 manifest, split, train, evaluate, export CLI modules
configs/            versioned training/inference configuration
scripts/            setup, acquisition, audit, local start/check
tests/              data, preprocessing, model contract, API tests
dataset/            tracked attribution; ignored archives/raw/derived/manifests
artifacts/          ignored models, metrics, calibration, logs
docs/               architecture, skills provenance, validation evidence
reference/          ignored unchanged upstream checkout
.agents/skills/     reviewed project-scoped agent skills
```

- React/Vite suits the local single-screen interface; no SSR/Next.js server, auth, database, Redis, queue, or cloud backend without requirements.
- Semantic HTML, CSS design tokens, accessible primitives where needed, Lucide icons, explicit async states. Avoid heavy dashboard frameworks and unnecessary state packages.
- FastAPI owns image validation/preprocessing/inference; frontend never downloads TensorFlow/weights. Load one verified model per process, bound concurrency, benchmark CPU threading.
- Vite `/api` proxy/same-origin delivery; bind development to loopback, not LAN.
- Typed response: task, ordered labels/scores, model version/hash, preprocessing version, latency, warnings, abstention. Validate at frontend boundary.
- Missing approved trained artifact means not-ready health and prediction 503 by default. Per explicit user request, a separate opt-in local experimental demo may serve an actually trained, evaluated, unreviewed research model with prominent limitations; it is not an approved release. Never substitute random weights, heuristics, or mocks silently.
- Decode JPEG/PNG/WebP with byte and pixel limits, EXIF orientation/RGB handling, corrupt/spoofed-file checks and decompression-bomb protection. MIME headers alone are insufficient.
- Uploads remain in memory, not logged/persisted by default. Revoke browser object URLs. No external upload or patient-image telemetry.
- Quality heuristics are not validated tongue/OOD detectors. Require intentional tongue uploads and disclose unsupported inputs; do not claim guaranteed tongue detection without evaluation.

## ML protocol and optimization

1. Resume archive download; verify size/MD5 before extraction. Inventory ZIP paths, reject traversal/absolute paths/unsafe links, bound extraction, check disk headroom.
2. Build manifest: source path, label, candidate subject ID, camera, original/crop family, dimensions, SHA-256. Reconcile CSV joins; quarantine missing/conflicting labels and corrupt images.
3. Verify ID semantics before grouping. Keep subject views/crops/originals together. Save seeded stratified group splits, approximately 70/15/15 only if minority subject counts permit; explicitly diagnose infeasible class coverage.
4. Audit exact and near-duplicates. Co-locate/exclude duplicates across subjects. No subject/view/crop family may cross train/validation/test.
5. Split BEFORE augmentation/balancing. Derive class weights from training only; keep validation/test unaugmented and unresampled.
6. DenseNet121 ImageNet frozen-backbone baseline, then selective low-LR fine tuning. `tf.data` parallel decode/prefetch, bounded cache, early stopping, checkpoints/resume, saved seed/config.
7. One architecture-specific preprocessing function shared between training/serving. DenseNet and Xception normalization differ; avoid double 1/255 rescaling.
8. Tiny smoke run, CPU-safe batch size, hardware discovery before full training. Modern native-Windows TensorFlow is CPU-first; GPU support ended after 2.10. WSL2 GPU only if actually available/configured, not a legacy downgrade.
9. Compare majority baseline; report macro-F1, balanced accuracy, per-class metrics, confusion matrix, calibration, camera subgroups, counts, subject-level uncertainty where feasible. No promised accuracy before experiments.
10. Select calibration/abstention using validation ONLY; freeze before final holdout. Softmax alone is not calibrated confidence or disease probability.
11. Optional MobileNet/EfficientNet or DenseNet/Xception ensemble requires measured benefit; no expensive broad sweep by default.
12. Export `.keras` plus ordered labels, input/preprocessing version, split/config hashes and model SHA-256. Verify reload prediction parity and inference/training parity.

## Skills and delegation policy

Install minimal reviewed skills, project-local, pin sources/lock/provenance. Read before use. Skills cannot override user/project safety constraints.

| Need | Candidate | Gate |
| --- | --- | --- |
| Discovery | `vercel-labs/skills`, `find-skills` | Verify CLI and skill name |
| React performance | `vercel-labs/agent-skills`, `vercel-react-best-practices` | Inspect, install for Codex |
| UI composition | same, `vercel-composition-patterns` | React-relevant guidance |
| Accessibility/design review | same, `web-design-guidelines` | Official Vercel source |
| UI/UX Pro Max | `nextlevelbuilder/ui-ux-pro-max-skill` | Verify path and include required scripts/data |
| TensorFlow/Keras | `mindrally/skills`, `tensorflow-deep-learning` | Reviewed third-party skill; no official endorsement |
| Browser testing | installed Codex browser/computer-use | Real localhost checks plus automated tests |

CLI shape after verifying version: `npx skills add vercel-labs/agent-skills --skill vercel-react-best-practices web-design-guidelines vercel-composition-patterns --agent codex --copy --yes`. Do not install all skills or globally by default. If no credible current ML skill exists, clearly label a small project-authored workflow grounded in official TensorFlow/Keras docs.

- Requested coordinator: GPT-6.1 Terra/high; workers: GPT-6 Luna/xhigh. Account rejected BOTH provider-qualified overrides; unqualified Luna alias is unknown. No successful execution on these models is claimed. This chat model cannot be changed through repository files.
- Avoid repeated failed dispatches and silent model relabeling. Continue locally when requested workers are unavailable.
- When available: at most two bounded workers, disjoint ownership (`apps/web/` and `ml/` plus respective tests); coordinator owns contracts, integration, dependency installation and gates. No duplicate installs/downloads/research.
- Load skills just in time, request compact evidence summaries, close completed workers, optimize based on measurements rather than feature count.

## Phased execution

### Phase 0 - Audit, plan, prerequisites, skills, data acquisition

- [x] Inspect existing Git without reset/branch/commit/remote changes.
- [x] Clone/audit upstream; record commit, labels, scope mismatch, license and leakage risk.
- [x] Resolve exact dataset version/size/checksum/license.
- [x] Write plan before application development.
- [x] Create data/runtime directories, ignore rules, attribution.
- [x] Recover npm with verified project-local Node 22.23.4; Python 3.13.1/TensorFlow 2.21.0 CPU compute passes. Hardware: 16 GB RAM, Intel Iris Xe; no TensorFlow GPU.
- [x] Review/install five skills; record pinned provenance and next-turn loading instructions in docs/skills.md.
- [x] Download all archive bytes, verify MD5, inventory and safely extract.
- [x] Install isolated/locked dependencies; runtime imports, pip check, npm audit, CLI tools, repeat setup and prerequisite tests pass. Web tooling uses Biome after removing the initial vulnerable ESLint transitive chain.
- Gate: archive verified and extracted; broader data and privacy review continues in Phase 1.
- Browser: N/A until a web surface exists.

### Phase 1 - Data audit and experiment contract

- Implement manifest/audit, verified grouping and saved stratified group splits.
- Tests: unsafe paths, corrupt files, labels/joins, conflicts, duplicates, group non-overlap, deterministic splits, class coverage, training-only weighting.
- Gate: reconcile archive/CSV counts, resolve discrepancies, demonstrate no subject/crop/duplicate leakage, record minority feasibility.
- Browser: N/A; no UI yet.

### Phase 2 - Training, evaluation, export

- Tiny preprocessing/training smoke test, then checkpointed DenseNet121 baseline/fine tuning.
- Save baseline comparison, metrics/counts/plots, calibration decisions, model card.
- Tests: input shape/range, finite ordered scores/loss, preprocessing parity, serialization roundtrip, metadata/hash rejection.
- Gate: REAL evaluated trained artifact plus honest report and reload parity. Slow CPU training remains pending; never fabricate metrics.
- Browser: N/A, CLI/artifact evidence applies.

### Phase 3 - Local inference API

- Health/readiness, model metadata, prediction endpoint; typed schema, strict bounded uploads and in-memory inference.
- Tests: valid/corrupt/oversized/spoofed/decompression inputs, missing upload/model, 503 readiness, concurrency, labels/provenance, no persistence.
- Gate: API contract suite plus separate integration with REAL approved artifact. Stub tests do not replace it.

### Phase 4 - React product interface

- Calm research workspace: warm neutral, restrained teal/ink, readable type, clear upload/results. No fake medical trust badges or accuracy statistics.
- Accessible dropzone/picker, preview/remove/replace, loading/cancel/retry/errors, score bars, provenance, privacy/limitations.
- Tests: keyboard/focus, validation, stale-response/cancel races, object URL cleanup, unavailable backend/abstention, responsive layout.
- Gate: TypeScript/lint/unit/build PASS; **Codex browser localhost** desktop/mobile, keyboard, malformed upload, backend unavailable, REAL prediction; record screenshots/outcomes.

### Phase 5 - Integration, measured optimization, local handoff

- One-command setup/start/check, reproducibility docs, dependency/license review, warm/cold p50/p95 latency and memory.
- Optimize measured bottlenecks only; quantization/ensembles require quality/latency comparison.
- Gate: real upload/result journey, ML/API/web suite, browser evidence, integrity/privacy checks, honest model card, reproducible instructions. Confirm images/archives/secrets/models/runtimes are untracked/unstaged.
- STOP at local handoff; no new GitHub repository, remote, commit, push, or publish until explicitly requested later.

## Evidence and done criteria

Maintain `docs/validation.md`: phase/date, exact command/environment, result, evidence and caveats. PASS means actually executed. Browser checks begin when a UI exists, not fabricated rituals for non-web phases.

Done requires an evaluated trained model driving a validated real upload-to-result flow with visible limitations and no data leakage. A polished UI, dependency install, or synthetic output alone is not completion.

Sources: https://www.tensorflow.org/install/pip ; https://keras.io/api/applications/densenet/ ; https://keras.io/api/applications/xception/ ; https://github.com/vercel-labs/skills
