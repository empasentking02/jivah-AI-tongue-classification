import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App";

beforeEach(() => {
  vi.stubGlobal(
    "fetch",
    vi.fn().mockResolvedValue(new Response('{"ready":false}')),
  );
  vi.stubGlobal("URL", {
    createObjectURL: vi.fn(() => "blob:preview"),
    revokeObjectURL: vi.fn(),
  });
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("image selection", () => {
  it.each(["image/jpeg", "image/png"])("accepts %s", (type) => {
    render(<App />);
    const input = screen.getByLabelText("Browse files");
    expect(input.getAttribute("accept")).toBe("image/jpeg,image/png");
    fireEvent.change(input, {
      target: { files: [new File(["image"], "image", { type })] },
    });
    expect(
      screen.getByAltText("Selected tongue photograph preview"),
    ).toBeTruthy();
    expect(
      screen
        .getByRole("button", { name: "Explore image" })
        .hasAttribute("disabled"),
    ).toBe(false);
  });

  it("rejects WebP files", () => {
    render(<App />);
    fireEvent.change(screen.getByLabelText("Browse files"), {
      target: {
        files: [new File(["image"], "image.webp", { type: "image/webp" })],
      },
    });
    expect(screen.getByRole("alert").textContent).toContain(
      "Choose a JPEG or PNG image.",
    );
    expect(
      screen
        .getByRole("button", { name: "Explore image" })
        .hasAttribute("disabled"),
    ).toBe(true);
  });
});

describe("research insights", () => {
  it("shows the top category and non-diagnostic next steps after a result", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockImplementation((url: string) =>
        Promise.resolve(
          new Response(
            url === "/api/health"
              ? '{"ready":true}'
              : JSON.stringify({
                  label: "Vata",
                  scores: [
                    { label: "Pitta", score: 0.67 },
                    { label: "Vata", score: 0.5 },
                    { label: "Kapha", score: 0.24 },
                  ],
                  warnings: ["Unreviewed experimental model"],
                }),
          ),
        ),
      ),
    );
    render(<App />);
    fireEvent.change(screen.getByLabelText("Browse files"), {
      target: {
        files: [new File(["image"], "image.png", { type: "image/png" })],
      },
    });
    fireEvent.click(screen.getByRole("button", { name: "Explore image" }));
    expect(screen.queryByText("HOW TO READ THIS")).toBeNull();
    expect(
      screen.getByRole("heading", { name: "Pitta food ideas" }),
    ).toBeTruthy();
    expect(screen.getByText(/Pitta leads · 67.0%/)).toBeTruthy();
    expect(screen.getByText("Coconut water")).toBeTruthy();
    expect(screen.getByText("Very hot chilies & spices")).toBeTruthy();
    expect(
      screen.getByText(/not a personalized diet plan or medical advice/),
    ).toBeTruthy();
    expect(screen.getByText("Unreviewed experimental model")).toBeTruthy();
  });

  it("shows non-medical capture tips before an image is selected", () => {
    render(<App />);
    expect(
      screen.getByRole("heading", {
        name: /clearer image makes a better research input/i,
      }),
    ).toBeTruthy();
    expect(screen.getByText("Even light")).toBeTruthy();
    expect(screen.getByText("Sharp focus")).toBeTruthy();
    expect(screen.getByText("Centered view")).toBeTruthy();
  });
});
