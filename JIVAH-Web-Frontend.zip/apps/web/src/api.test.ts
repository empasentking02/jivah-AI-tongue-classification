import { afterEach, describe, expect, it, vi } from "vitest";
import { checkHealth, predict } from "./api";

const signal = new AbortController().signal;
const file = new File(["image"], "test.png", { type: "image/png" });
afterEach(() => vi.unstubAllGlobals());

describe("local API adapter", () => {
  it("reads the readiness boolean and handles an offline API", async () => {
    vi.stubGlobal(
      "fetch",
      vi
        .fn()
        .mockResolvedValueOnce(new Response(JSON.stringify({ ready: true })))
        .mockRejectedValueOnce(new Error("offline")),
    );
    expect(await checkHealth(signal)).toBe("ready");
    expect(await checkHealth(signal)).toBe("offline");
  });
  it("submits the image using the agreed multipart field", async () => {
    const result = {
      label: "Pitta",
      model_sha256: "abc123",
      scores: [
        { label: "Pitta", score: 0.6 },
        { label: "Vata", score: 0.3 },
        { label: "Kapha", score: 0.1 },
      ],
    };
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(new Response('{"ready":true}'))
      .mockResolvedValueOnce(new Response(JSON.stringify(result)));
    vi.stubGlobal("fetch", fetchMock);
    expect(await predict(file, signal)).toEqual(result);
    expect(fetchMock.mock.calls[1][0]).toBe("/api/predict");
    expect((fetchMock.mock.calls[1][1].body as FormData).get("image")).toBe(
      file,
    );
  });
  it("never substitutes a result when the model is unavailable or the response is invalid", async () => {
    vi.stubGlobal(
      "fetch",
      vi
        .fn()
        .mockResolvedValueOnce(new Response('{"ready":false}'))
        .mockResolvedValueOnce(new Response('{"ready":true}'))
        .mockResolvedValueOnce(new Response("{}")),
    );
    await expect(predict(file, signal)).rejects.toThrow("model is unavailable");
    await expect(predict(file, signal)).rejects.toThrow("unexpected response");
  });
  it("does not upload an image when the model is unavailable", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(new Response('{"ready":false}'));
    vi.stubGlobal("fetch", fetchMock);
    await expect(predict(file, signal)).rejects.toThrow("model is unavailable");
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(fetchMock.mock.calls[0][0]).toBe("/api/health");
  });
});
