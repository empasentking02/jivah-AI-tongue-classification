export type TriDhatLabel = "Pitta" | "Vata" | "Kapha";

type FoodItem = { name: string; note: string };
export type DietGuide = {
  title: string;
  subtitle: string;
  favor: FoodItem[];
  limit: FoodItem[];
};

// Static educational copy. It is selected by the model's top class score,
// but is not a personal nutrition assessment or treatment recommendation.
export const dietGuides: Record<TriDhatLabel, DietGuide> = {
  Pitta: {
    title: "Pitta food ideas",
    subtitle: "A traditional-style list for a classroom demonstration.",
    favor: [
      {
        name: "Coconut water",
        note: "An optional drink; plain water is also a good everyday choice.",
      },
      {
        name: "Cucumber & mint",
        note: "Fresh ingredients for salads, sides, or flavoring water.",
      },
      {
        name: "Whole fruits",
        note: "Melon, grapes, pears, and mango are examples; choose portions that suit you.",
      },
      {
        name: "Leafy greens",
        note: "Spinach, kale, and lettuce add variety to meals.",
      },
      {
        name: "Oats & rice",
        note: "Flexible grain choices; choose higher-fibre options when they fit your diet.",
      },
    ],
    limit: [
      {
        name: "Very hot chilies & spices",
        note: "The traditional list favors milder seasoning; adjust to your taste.",
      },
      {
        name: "Fried or oily foods",
        note: "Keep these occasional as part of an overall varied eating pattern.",
      },
      {
        name: "Very sour foods",
        note: "Citrus is not automatically unsuitable; consider your own preference and needs.",
      },
      {
        name: "Alcohol & caffeine",
        note: "This score is not a reason to start, stop, or change either.",
      },
      {
        name: "Meat and other protein foods",
        note: "Do not remove a protein source solely because of this model result.",
      },
    ],
  },
  Vata: {
    title: "Vata food ideas",
    subtitle: "A traditional-style list for a classroom demonstration.",
    favor: [
      {
        name: "Warm soups & stews",
        note: "A traditional example of a warm, moist meal.",
      },
      {
        name: "Oats, rice, or other grains",
        note: "Choose grains that fit your usual meals and dietary needs.",
      },
      {
        name: "Cooked vegetables",
        note: "Use a variety of vegetables available to you.",
      },
      {
        name: "Beans and pulses",
        note: "Include a suitable protein source if it is part of your diet.",
      },
      {
        name: "Regular meal patterns",
        note: "A routine is a traditional suggestion, not a requirement from the model.",
      },
    ],
    limit: [
      {
        name: "Very cold or dry foods",
        note: "This is a traditional taste/texture preference, not a medical restriction.",
      },
      {
        name: "Bitter, astringent, or very pungent foods",
        note: "The traditional list suggests moderation; personal tolerance varies.",
      },
      {
        name: "Skipping meals",
        note: "The model cannot determine meal timing or energy needs.",
      },
    ],
  },
  Kapha: {
    title: "Kapha food ideas",
    subtitle: "A traditional-style list for a classroom demonstration.",
    favor: [
      {
        name: "A variety of vegetables",
        note: "Leafy greens and other vegetables can add color and variety.",
      },
      {
        name: "Beans and pulses",
        note: "A familiar protein option in many meal patterns.",
      },
      {
        name: "Oats, millets, or other grains",
        note: "Choose a grain variety that suits your meals and needs.",
      },
      {
        name: "Warm, lightly seasoned dishes",
        note: "A traditional food-style example; season to your preference.",
      },
    ],
    limit: [
      {
        name: "Fried or very oily foods",
        note: "Keep these occasional as part of an overall varied eating pattern.",
      },
      {
        name: "Very salty foods",
        note: "The traditional reference suggests using salt sparingly.",
      },
      {
        name: "Heavy, very cold desserts",
        note: "A traditional preference, not a rule based on health or body type.",
      },
      {
        name: "Fasting or skipping meals",
        note: "Do not fast because of this model output.",
      },
    ],
  },
};
