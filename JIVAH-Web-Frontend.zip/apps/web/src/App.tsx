import {
  ArrowRight,
  Check,
  CircleHelp,
  Focus,
  Frame,
  ImagePlus,
  LockKeyhole,
  Microscope,
  Sparkles,
  Sun,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { checkHealth, type Prediction, predict } from "./api";
import { dietGuides } from "./dietGuides";

const acceptedTypes = ["image/jpeg", "image/png"];
const maxBytes = 10 * 1024 * 1024;

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [result, setResult] = useState<Prediction | null>(null);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [status, setStatus] = useState<
    "checking" | "ready" | "unavailable" | "offline"
  >("checking");
  const inputRef = useRef<HTMLInputElement>(null);
  const requestRef = useRef<AbortController | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    void checkHealth(controller.signal).then((value) => {
      if (!controller.signal.aborted) setStatus(value);
    });
    return () => controller.abort();
  }, []);
  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);
  useEffect(() => () => requestRef.current?.abort(), []);

  function selectFile(selected: File | undefined) {
    requestRef.current?.abort();
    requestRef.current = null;
    setBusy(false);
    setResult(null);
    setFile(null);
    if (inputRef.current) inputRef.current.value = "";
    if (!selected) {
      setError("");
      return;
    }
    if (!acceptedTypes.includes(selected.type)) {
      setError("Choose a JPEG or PNG image.");
      return;
    }
    if (selected.size === 0 || selected.size > maxBytes) {
      setError("Choose a non-empty image no larger than 10 MB.");
      return;
    }
    setError("");
    setFile(selected);
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!file || busy) return;
    const controller = new AbortController();
    requestRef.current = controller;
    setError("");
    setResult(null);
    setBusy(true);
    try {
      const value = await predict(file, controller.signal);
      if (!controller.signal.aborted) {
        setResult(value);
        setStatus("ready");
      }
    } catch (caught) {
      if (!controller.signal.aborted)
        setError(
          caught instanceof Error
            ? caught.message
            : "Something went wrong. Please try again.",
        );
    } finally {
      if (requestRef.current === controller) {
        requestRef.current = null;
        setBusy(false);
      }
    }
  }

  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="site-header">
        <div className="header-inner">
          <a href="#main" className="brand" aria-label="Jeevah home">
            <span className="brand-mark">
              <Sparkles size={19} aria-hidden="true" />
            </span>
            <span>
              jeevah<span className="brand-dot">.</span>
            </span>
          </a>
          <span className="header-label">
            <Microscope size={15} aria-hidden="true" /> A RESEARCH EXPLORATION
          </span>
        </div>
      </header>
      <main id="main">
        <section className="hero" aria-labelledby="page-title">
          <div className="eyebrow">
            <span className="eyebrow-dot" /> TRADITIONAL THAI MEDICINE ·
            TRI-DHAT
          </div>
          <h1 id="page-title">
            A closer look at
            <br />
            <em>traditional patterns.</em>
          </h1>
          <p>
            Explore research into Tri-Dhat classification through tongue images.
            A starting point for inquiry, not an answer about your health.
          </p>
          <div className="hero-stamp">
            <span>FIELD NOTE 01</span>
            <span>LOCAL MODEL · TRI-DHAT</span>
          </div>
        </section>
        <div className="workspace">
          <section className="card upload-card" aria-labelledby="upload-title">
            <div className="card-heading">
              <div>
                <span className="step">01 / IMAGE</span>
                <h2 id="upload-title">Start with an image</h2>
                <p>Choose one clear tongue photograph to explore.</p>
              </div>
              <span className="heading-icon">
                <ImagePlus size={21} aria-hidden="true" />
              </span>
            </div>
            <form onSubmit={submit}>
              <fieldset
                aria-label="Image selection"
                className={`dropzone${dragging ? " is-dragging" : ""}${preview ? " has-preview" : ""}`}
                onDragOver={(event) => {
                  event.preventDefault();
                  setDragging(true);
                }}
                onDragLeave={() => setDragging(false)}
                onDrop={(event) => {
                  event.preventDefault();
                  setDragging(false);
                  if (event.dataTransfer.files.length !== 1) {
                    selectFile(undefined);
                    setError("Choose exactly one image.");
                  } else selectFile(event.dataTransfer.files[0]);
                }}
              >
                {preview && file ? (
                  <div className="preview">
                    <img
                      src={preview}
                      alt="Selected tongue photograph preview"
                    />
                    <div className="preview-info">
                      <span>
                        <Check size={16} aria-hidden="true" /> Image selected
                      </span>
                      <strong>{file.name}</strong>
                    </div>
                    <button
                      className="remove"
                      type="button"
                      onClick={() => selectFile(undefined)}
                      aria-label="Remove selected image"
                    >
                      <X size={17} aria-hidden="true" />
                    </button>
                  </div>
                ) : (
                  <>
                    <span className="upload-icon">
                      <ImagePlus size={25} aria-hidden="true" />
                    </span>
                    <strong>Drop your image here</strong>
                    <span className="or">
                      or choose a file from your device
                    </span>
                  </>
                )}
                <label className="file-button" htmlFor="image-input">
                  {file ? "Choose another image" : "Browse files"}
                </label>
                <input
                  ref={inputRef}
                  id="image-input"
                  type="file"
                  accept="image/jpeg,image/png"
                  onChange={(event) => selectFile(event.target.files?.[0])}
                  aria-describedby={`file-help${error ? " file-error" : ""}`}
                  aria-invalid={Boolean(error)}
                />
              </fieldset>
              <div className="file-meta" id="file-help">
                <span>JPEG or PNG</span>
                <span>Maximum 10 MB</span>
              </div>
              {error && (
                <p className="error" id="file-error" role="alert">
                  {error}
                </p>
              )}
              <button className="submit" type="submit" disabled={!file || busy}>
                {busy ? "Sending to local API…" : "Explore image"}
                <ArrowRight size={18} aria-hidden="true" />
              </button>
              <p className="privacy">
                <LockKeyhole size={14} aria-hidden="true" /> Preview stays in
                your browser until you submit to the local API.
              </p>
            </form>
            {result && <RecommendationPanel result={result} />}
          </section>
          <section
            className="card results-card"
            aria-labelledby="results-title"
            aria-live="polite"
            aria-busy={busy}
          >
            <div className="card-heading">
              <div>
                <span className="step">02 / EXPLORATION</span>
                <h2 id="results-title">Your research output</h2>
                <p>Results appear here when a model is available.</p>
              </div>
              <span className="heading-icon muted">
                <Sparkles size={21} aria-hidden="true" />
              </span>
            </div>
            <p className={`status ${status}`}>
              <span />
              {status === "checking"
                ? "Checking local model…"
                : status === "ready"
                  ? "Local model ready"
                  : "Local model unavailable or API offline"}
            </p>
            {result ? (
              <Results result={result} />
            ) : (
              <div className="empty-state">
                <div className="orbit">
                  <div>
                    <Sparkles size={25} aria-hidden="true" />
                  </div>
                </div>
                <h3>
                  {busy
                    ? "Exploring your image"
                    : "A little space for discovery"}
                </h3>
                <p>
                  {busy
                    ? "Waiting for the local API to respond."
                    : "Select an image and submit it to see the model’s research output here."}
                </p>
                <span className="empty-tag">NO RESULT YET</span>
              </div>
            )}
          </section>
        </div>
        <section className="capture-guide" aria-labelledby="capture-title">
          <div className="capture-intro">
            <span className="step">BEFORE YOU BEGIN</span>
            <h2 id="capture-title">
              A clearer image makes a better research input.
            </h2>
            <p>
              Simple capture tips help keep the image conditions consistent.
            </p>
          </div>
          <ul className="capture-steps">
            <li>
              <Sun size={18} aria-hidden="true" />
              <span>
                <strong>Even light</strong>
                <small>Use bright, indirect light.</small>
              </span>
            </li>
            <li>
              <Focus size={18} aria-hidden="true" />
              <span>
                <strong>Sharp focus</strong>
                <small>Hold still; avoid filters.</small>
              </span>
            </li>
            <li>
              <Frame size={18} aria-hidden="true" />
              <span>
                <strong>Centered view</strong>
                <small>Keep the tongue in frame.</small>
              </span>
            </li>
          </ul>
        </section>
        <aside className="notice">
          <span className="notice-icon">
            <CircleHelp size={19} aria-hidden="true" />
          </span>
          <div>
            <strong>For research, not diagnosis.</strong>
            <p>
              Jeevah explores Traditional Thai Medicine’s Pitta, Vata and Kapha
              categories. These are not disease diagnoses, and model scores are
              not disease probabilities. This tool is not clinically validated
              and should not guide medical decisions.
            </p>
          </div>
        </aside>
        <section className="principles" aria-label="About this exploration">
          <div>
            <span>01</span>
            <strong>Research first</strong>
            <p>
              An exploration of traditional categories, grounded in the limits
              of the data.
            </p>
          </div>
          <div>
            <span>02</span>
            <strong>Considered by design</strong>
            <p>
              Image selection and preview happen on your device before
              submission.
            </p>
          </div>
          <div>
            <span>03</span>
            <strong>Transparent output</strong>
            <p>
              Results include model provenance and research limitations when
              available.
            </p>
          </div>
        </section>
      </main>
      <footer>
        <span className="footer-brand">
          jeevah<span>.</span>
        </span>
        <span>Research exploration · Made for curiosity, not clinical use</span>
        <span>TRI-DHAT / 01</span>
      </footer>
    </>
  );
}

function Results({ result }: { result: Prediction }) {
  const orderedScores = [...result.scores].sort(
    (first, second) => second.score - first.score,
  );
  const highestScore = orderedScores[0]?.score;
  const leaders = orderedScores.filter((item) => item.score === highestScore);
  const dominant = leaders.length === 1 ? leaders[0] : undefined;
  return (
    <div className="result-content">
      {result.abstained ? (
        <p className="abstained">
          The model abstained; no classification is presented.
        </p>
      ) : (
        <>
          <div className="result-layout">
            <div className="score-panel">
              <p className="result-kicker">
                TOP MODEL CLASS{" "}
                <span>Scores are not disease probabilities</span>
              </p>
              {dominant ? (
                <div className="dominant-class">
                  <strong>{dominant.label}</strong>
                  <span>{(dominant.score * 100).toFixed(1)}% model score</span>
                </div>
              ) : (
                <p className="tie-note">
                  The top model score is tied, so no single category is
                  selected.
                </p>
              )}
              <div className="score-heading">
                <span>THREE CLASS SCORES</span>
                <span>Research output · not body composition</span>
              </div>
              <ul className="scores">
                {orderedScores.map((item, index) => (
                  <li key={item.label}>
                    <div className="score-label">
                      <span className={`score-rank rank-${index + 1}`}>
                        {String(index + 1).padStart(2, "0")}
                      </span>
                      <strong>{item.label}</strong>
                    </div>
                    <div>
                      <span>{(item.score * 100).toFixed(1)}%</span>
                    </div>
                    <div
                      className={`score-track score-${item.label.toLowerCase()}`}
                    >
                      <div style={{ width: `${item.score * 100}%` }} />
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </>
      )}
      {result.warnings && result.warnings.length > 0 && (
        <div className="warnings">
          <strong>Model notes</strong>
          <ul>
            {result.warnings.map((warning, index) => (
              <li key={`${index}-${warning}`}>{warning}</li>
            ))}
          </ul>
        </div>
      )}
      {(result.model_version ||
        result.model_sha256 ||
        result.preprocessing_version ||
        result.latency_ms !== undefined) && (
        <details>
          <summary>Model provenance</summary>
          <dl>
            {result.model_version && (
              <>
                <dt>Version</dt>
                <dd>{result.model_version}</dd>
              </>
            )}
            {result.model_sha256 && (
              <>
                <dt>Model hash</dt>
                <dd className="hash">{result.model_sha256}</dd>
              </>
            )}
            {result.preprocessing_version && (
              <>
                <dt>Preprocessing</dt>
                <dd>{result.preprocessing_version}</dd>
              </>
            )}
            {result.latency_ms !== undefined && (
              <>
                <dt>Latency</dt>
                <dd>{result.latency_ms.toFixed(0)} ms</dd>
              </>
            )}
          </dl>
        </details>
      )}
    </div>
  );
}

function RecommendationPanel({ result }: { result: Prediction }) {
  if (result.abstained) return null;
  const orderedScores = [...result.scores].sort(
    (first, second) => second.score - first.score,
  );
  const highestScore = orderedScores[0]?.score;
  const leaders = orderedScores.filter((item) => item.score === highestScore);
  const dominant = leaders.length === 1 ? leaders[0] : undefined;
  const guide = dominant ? dietGuides[dominant.label] : undefined;

  return guide && dominant ? (
    <DietRecommendation
      label={dominant.label}
      score={dominant.score}
      guide={guide}
    />
  ) : (
    <div className="diet-guide tie-guide">
      <span className="step">FOOD GUIDE</span>
      <h3>No single leading category</h3>
      <p className="diet-subtitle">
        Food ideas stay hidden when the top scores are tied.
      </p>
    </div>
  );
}

function DietRecommendation({
  label,
  score,
  guide,
}: {
  label: "Pitta" | "Vata" | "Kapha";
  score: number;
  guide: (typeof dietGuides)["Pitta"];
}) {
  return (
    <section className="diet-guide" aria-labelledby="diet-guide-title">
      <div className="diet-guide-heading">
        <span className="step">FOOD GUIDE · TRADITIONAL REFERENCE</span>
        <span className="guide-score">
          {label} leads · {(score * 100).toFixed(1)}%
        </span>
      </div>
      <h3 id="diet-guide-title">{guide.title}</h3>
      <p className="diet-subtitle">{guide.subtitle}</p>
      <div className="food-columns">
        <FoodList title="Foods to Favor" foods={guide.favor} />
        <FoodList title="Foods to Limit" foods={guide.limit} />
      </div>
      <p className="diet-disclaimer">
        This is a traditional-style demonstration selected by the top model
        score, not a personalized diet plan or medical advice. Do not avoid
        foods or change your diet based on this result. Food needs vary; seek
        qualified dietitian or clinician advice for personal guidance.
      </p>
      <div className="diet-sources">
        <a
          href="https://pharmacy.mahidol.ac.th/knowledge/files/0071.pdf"
          target="_blank"
          rel="noreferrer"
        >
          Traditional food framework reference
        </a>
        <a
          href="https://www.nin.res.in/dietaryguidelines/pdfjs/locale/DGI24thJune2024fin.pdf"
          target="_blank"
          rel="noreferrer"
        >
          ICMR-NIN balanced diet guidance
        </a>
      </div>
    </section>
  );
}

function FoodList({
  title,
  foods,
}: {
  title: string;
  foods: { name: string; note: string }[];
}) {
  return (
    <div className="food-list">
      <h4>{title}</h4>
      <ul>
        {foods.map((food) => (
          <li key={food.name}>
            <strong>{food.name}</strong>
            <span>{food.note}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
