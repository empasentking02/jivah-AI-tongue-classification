import { z } from "zod";

const score = z.object({
  label: z.enum(["Pitta", "Vata", "Kapha"]),
  score: z.number().finite().min(0).max(1),
});
const prediction = z.object({
  label: z.enum(["Pitta", "Vata", "Kapha"]),
  scores: z
    .array(score)
    .length(3)
    .refine((items) => new Set(items.map((item) => item.label)).size === 3),
  model_version: z.string().optional(),
  model_sha256: z.string().optional(),
  preprocessing_version: z.string().optional(),
  latency_ms: z.number().finite().nonnegative().optional(),
  warnings: z.array(z.string()).optional(),
  abstained: z.boolean().optional(),
});
const health = z.object({ ready: z.boolean() });
export type Prediction = z.infer<typeof prediction>;

export async function checkHealth(
  signal: AbortSignal,
): Promise<"ready" | "unavailable" | "offline"> {
  try {
    const response = await fetch("/api/health", { signal });
    if (!response.ok) return "offline";
    const parsed = health.safeParse(await response.json());
    return parsed.success
      ? parsed.data.ready
        ? "ready"
        : "unavailable"
      : "offline";
  } catch {
    return "offline";
  }
}

export async function predict(
  file: File,
  signal: AbortSignal,
): Promise<Prediction> {
  const readiness = await checkHealth(signal);
  if (signal.aborted) throw new DOMException("Request aborted", "AbortError");
  if (readiness === "offline")
    throw new Error(
      "Cannot reach the local API. Make sure it is running, then try again.",
    );
  if (readiness === "unavailable")
    throw new Error(
      "The model is unavailable. An approved trained model must be available before predictions can run.",
    );
  const data = new FormData();
  data.append("image", file);
  let response: Response;
  try {
    response = await fetch("/api/predict", {
      method: "POST",
      body: data,
      signal,
    });
  } catch (error) {
    if (signal.aborted) throw error;
    throw new Error(
      "Cannot reach the local API. Make sure it is running, then try again.",
    );
  }
  if (response.status === 503)
    throw new Error(
      "The model is unavailable. An approved trained model must be available before predictions can run.",
    );
  if (!response.ok) {
    const detail = z
      .object({ detail: z.string() })
      .safeParse(await response.json().catch(() => null));
    throw new Error(
      detail.success
        ? detail.data.detail
        : `The local API could not process the image (HTTP ${response.status}).`,
    );
  }
  const parsed = prediction.safeParse(await response.json().catch(() => null));
  if (!parsed.success)
    throw new Error(
      "The API returned an unexpected response. No result is shown.",
    );
  return parsed.data;
}
