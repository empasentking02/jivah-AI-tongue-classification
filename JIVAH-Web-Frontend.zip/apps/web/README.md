# Jeevah web

From the repository root: `./scripts/npm.ps1 --prefix apps/web run dev`. The Vite server binds to loopback and proxies `/api` to `http://127.0.0.1:8000`. No external image service is used. The API and approved model are not yet available.

The API adapter in `src/api.ts` expects `GET /api/health` to include `{ "ready": boolean }` and `POST /api/predict` to accept a JPEG or PNG in multipart field `image`. A successful response includes `label` and `scores: [{label, score}]` for each of Pitta, Vata, Kapha (scores in [0,1]). Optional provenance, including `model_sha256`, and warning fields are displayed when present. HTTP 503 means unavailable. Unexpected responses fail closed; reconcile other optional fields with the backend when finalized.
