"""Local research inference API."""
