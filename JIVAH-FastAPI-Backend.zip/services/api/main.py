"""Local, fail-closed research inference service."""

import asyncio
import hashlib
import io
import json
import os
import re
from contextlib import asynccontextmanager, suppress
from email import policy
from email.parser import BytesParser
from pathlib import Path
from typing import Literal

import numpy as np
from fastapi import FastAPI, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from PIL import Image, UnidentifiedImageError
from pydantic import BaseModel, ConfigDict, Field

from ml.split import LABELS as TRAIN_LABELS
from ml.train import PREPROCESSING as TRAIN_PREPROCESSING

UNAVAILABLE = "No approved, evaluated model and preprocessing contract are available."
NOTICE = "Research-only Traditional Thai Medicine classification; not a medical diagnosis."
EXPERIMENTAL_NOTICE = (
    "Unreviewed experimental model; never a medical diagnosis. Artifact reports and split "
    "have not been independently verified for serving."
)
MAX_IMAGE_BYTES = 10 * 1024 * 1024
MAX_BODY = MAX_IMAGE_BYTES + 64 * 1024
MAX_PIXELS = 20_000_000
LABELS = ("Pitta", "Vata", "Kapha")
PREPROCESSING = "rgb-bilinear-224-densenet-v1"


class Health(BaseModel):
    status: str
    ready: bool


class Error(BaseModel):
    detail: str


class CategoryScore(BaseModel):
    label: Literal["Pitta", "Vata", "Kapha"]
    score: float = Field(allow_inf_nan=False)


class Prediction(BaseModel):
    label: Literal["Pitta", "Vata", "Kapha"]
    scores: list[CategoryScore]
    model_version: str
    model_sha256: str
    preprocessing_version: str
    warnings: list[str]


class Metadata(BaseModel):
    model_config = ConfigDict(extra="ignore", strict=True)

    model_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    split_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    approval_sha256: str | None = Field(pattern=r"^[0-9a-f]{64}$")
    research_only: bool | None = None
    experimental: bool | None = None
    evaluation_notice: str | None = None
    preprocessing: Literal[PREPROCESSING]
    labels: dict[str, str]
    input: dict
    config: dict


class Evaluation(BaseModel):
    model_config = ConfigDict(extra="ignore", strict=True)

    research_only: Literal[True]
    split: Literal["test"]
    model_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    split_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    labels: dict[str, str]
    count: int = Field(gt=0)
    subject_count: int = Field(gt=0)
    macro_f1: float = Field(ge=0, le=1, allow_inf_nan=False)
    balanced_accuracy: float = Field(ge=0, le=1, allow_inf_nan=False)
    per_class: dict | None = None


class ServingApproval(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    approved: Literal[True]
    model_version: str = Field(min_length=1, max_length=128)
    model_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    split_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    metadata_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    evaluation_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    reviewer: str = Field(min_length=1, max_length=256)
    evidence: str = Field(min_length=1, max_length=4096)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_artifact():
    model_path = Path(os.environ["JEEVAH_MODEL_PATH"])
    metadata_path = Path(os.environ["JEEVAH_METADATA_PATH"])
    evaluation_path = Path(os.environ["JEEVAH_EVALUATION_PATH"])
    metadata_bytes = metadata_path.read_bytes()
    evidence_bytes = evaluation_path.read_bytes()
    if json.loads(evidence_bytes).get("research_only") is not True:
        raise ValueError("Evaluation research boundary missing")
    metadata = Metadata.model_validate_json(metadata_bytes)
    evidence = Evaluation.model_validate_json(evidence_bytes)
    experimental = os.environ.get("JEEVAH_EXPERIMENTAL") == "1" and metadata.experimental is True
    approval = None
    if experimental:
        if metadata.research_only is not True:
            raise ValueError("Experimental research boundary missing")
        if evidence.macro_f1 < 0.5:
            notice = f"Low preliminary test performance: macro F1 {evidence.macro_f1:.2f}."
            vata = (evidence.per_class or {}).get("Vata", {})
            if isinstance(vata, dict) and vata.get("recall") == 0 and vata.get("support", 0) > 0:
                notice += " No Vata test images were classified correctly."
            metadata = metadata.model_copy(update={"evaluation_notice": notice})
    else:
        if metadata.experimental is True or metadata.approval_sha256 is None:
            raise ValueError("Approved training metadata required")
        approval_bytes = Path(os.environ["JEEVAH_SERVING_APPROVAL_PATH"]).read_bytes()
        if json.loads(approval_bytes).get("approved") is not True:
            raise ValueError("Model approval missing")
        approval = ServingApproval.model_validate_json(approval_bytes)
        if (
            digest(metadata_bytes) != approval.metadata_sha256
            or digest(evidence_bytes) != approval.evaluation_sha256
            or approval.model_sha256 != metadata.model_sha256
            or approval.split_sha256 != metadata.split_sha256
            or not approval.reviewer.strip()
            or not approval.evidence.strip()
        ):
            raise ValueError("Artifact provenance mismatch")
    expected_labels = {"0": "Pitta", "1": "Vata", "2": "Kapha"}
    expected_input = {
        "shape": [None, 224, 224, 3],
        "dtype": "float32",
        "range": [0, 255],
        "color": "RGB",
    }
    if (
        model_path.suffix != ".keras"
        or TRAIN_PREPROCESSING != PREPROCESSING
        or TRAIN_LABELS != expected_labels
        or metadata.labels != expected_labels
        or evidence.labels != expected_labels
        or metadata.input != expected_input
        or digest(model_path.read_bytes()) != metadata.model_sha256
        or evidence.model_sha256 != metadata.model_sha256
        or evidence.split_sha256 != metadata.split_sha256
        or evidence.subject_count > evidence.count
    ):
        raise ValueError("Artifact provenance mismatch")
    import tensorflow as tf

    model = tf.keras.models.load_model(model_path, compile=False, safe_mode=True)
    if digest(model_path.read_bytes()) != metadata.model_sha256:
        raise ValueError("Artifact changed while loading")
    if tuple(model.input_shape) != (None, 224, 224, 3) or tuple(model.output_shape) != (None, 3):
        raise ValueError("Unexpected model shape")
    if str(model.inputs[0].dtype) != "float32":
        raise ValueError("Unexpected model input dtype")
    return model, metadata, approval


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.artifact = None
    app.state.limit = asyncio.Semaphore(1)
    with suppress(Exception):
        app.state.artifact = await run_in_threadpool(load_artifact)
    yield


app = FastAPI(title="Jeevah research API", description=NOTICE, lifespan=lifespan)


def artifact(request: Request):
    value = request.app.state.artifact
    if value is None:
        raise HTTPException(status_code=503, detail=UNAVAILABLE)
    return value


@app.get("/api/health", response_model=Health)
def health(request: Request) -> Health:
    return Health(status="ok", ready=request.app.state.artifact is not None)


@app.get("/api/ready", responses={503: {"model": Error}})
def readiness(request: Request) -> Health:
    artifact(request)
    return Health(status="ok", ready=True)


@app.get("/api/model", responses={503: {"model": Error}})
def model_metadata(request: Request) -> dict:
    _, metadata, approval = artifact(request)
    version = approval.model_version if approval else f"experimental-{metadata.model_sha256[:12]}"
    result = {**metadata.model_dump(), "model_version": version}
    if approval is None:
        result["warnings"] = [NOTICE, EXPERIMENTAL_NOTICE]
    return result


async def read_body(request: Request, *, discard: bool = False) -> bytes:
    length = request.headers.get("content-length")
    if length is not None:
        if not re.fullmatch(r"[0-9]+", length):
            raise HTTPException(status_code=400, detail="Invalid Content-Length")
        if len(length) > 20 or int(length) > MAX_BODY:
            raise HTTPException(status_code=413, detail="Upload too large")
    body = bytearray()
    total = 0
    async for chunk in request.stream():
        total += len(chunk)
        if total > MAX_BODY:
            raise HTTPException(status_code=413, detail="Upload too large")
        if not discard:
            body.extend(chunk)
    return bytes(body)


def decode_image(content_type: str, body: bytes) -> np.ndarray:
    if not content_type.lower().startswith("multipart/form-data;"):
        raise HTTPException(status_code=415, detail="Expected multipart/form-data")
    try:
        header = content_type.encode("ascii")
        if b"\r" in header or b"\n" in header:
            raise ValueError
        message = BytesParser(policy=policy.default).parsebytes(
            b"Content-Type: " + header + b"\r\nMIME-Version: 1.0\r\n\r\n" + body
        )
        if message.defects or not message.is_multipart():
            raise ValueError
        parts = list(message.iter_parts())
        if len(parts) != 1 or parts[0].defects:
            raise ValueError
        part = parts[0]
        if (
            part.get_content_disposition() != "form-data"
            or part.get_param("name", header="content-disposition") != "image"
            or not part.get_filename()
            or part.get("Content-Transfer-Encoding") is not None
        ):
            raise ValueError
        mime = part.get_content_type()
        formats = {"image/jpeg": "JPEG", "image/png": "PNG"}
        if mime not in formats:
            raise HTTPException(status_code=415, detail="Unsupported image type")
        data = part.get_payload(decode=True)
        if not data:
            raise ValueError
        if len(data) > MAX_IMAGE_BYTES:
            raise HTTPException(status_code=413, detail="Image exceeds 10 MiB")
        with Image.open(io.BytesIO(data), formats=[formats[mime]]) as image:
            if image.format != formats[mime] or image.width * image.height > MAX_PIXELS:
                raise ValueError
            if getattr(image, "n_frames", 1) != 1:
                raise ValueError
            image.verify()
        import tensorflow as tf

        with suppress(Exception):
            image = tf.io.decode_image(data, channels=3, expand_animations=False)
            image = tf.image.resize(image, [224, 224], method="bilinear", antialias=False)
            return np.asarray(image, dtype=np.float32)[None, ...]
        raise ValueError
    except HTTPException:
        raise
    except (
        ValueError,
        TypeError,
        UnicodeError,
        OSError,
        UnidentifiedImageError,
        Image.DecompressionBombError,
    ):
        raise HTTPException(status_code=400, detail="Invalid image upload") from None


def infer(model, metadata, approval, inputs: np.ndarray) -> Prediction:
    output = np.asarray(model(inputs, training=False))
    if (
        output.shape != (1, 3)
        or not np.isfinite(output).all()
        or (output < 0).any()
        or (output > 1).any()
        or not np.allclose(output.sum(axis=1), 1, atol=1e-5)
    ):
        raise ValueError("Invalid model output")
    scores = [
        CategoryScore(label=label, score=float(score)) for label, score in zip(LABELS, output[0])
    ]
    scores.sort(key=lambda item: item.score, reverse=True)
    return Prediction(
        label=scores[0].label,
        scores=scores,
        model_version=(
            approval.model_version if approval else f"experimental-{metadata.model_sha256[:12]}"
        ),
        model_sha256=metadata.model_sha256,
        preprocessing_version=metadata.preprocessing,
        warnings=[NOTICE, "Scores are not disease probabilities or clinical diagnoses."]
        + ([EXPERIMENTAL_NOTICE] if approval is None else [])
        + ([metadata.evaluation_notice] if metadata.evaluation_notice else []),
    )


@app.post(
    "/api/predict",
    response_model=Prediction,
    responses={503: {"model": Error}},
    openapi_extra={
        "requestBody": {
            "required": True,
            "content": {
                "multipart/form-data": {
                    "schema": {
                        "type": "object",
                        "required": ["image"],
                        "properties": {"image": {"type": "string", "format": "binary"}},
                    }
                }
            },
        }
    },
)
async def predict(request: Request) -> Prediction:
    if request.app.state.artifact is None:
        await read_body(request, discard=True)
        raise HTTPException(status_code=503, detail=UNAVAILABLE)
    model, metadata, approval = artifact(request)
    async with request.app.state.limit:
        body = await read_body(request)
        inputs = await run_in_threadpool(
            decode_image, request.headers.get("content-type", ""), body
        )
        with suppress(Exception):
            return await run_in_threadpool(infer, model, metadata, approval, inputs)
        raise HTTPException(status_code=503, detail="Model inference unavailable")
